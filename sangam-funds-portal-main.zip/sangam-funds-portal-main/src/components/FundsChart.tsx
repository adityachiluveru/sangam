
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from "recharts";

const data = [
  { name: "Available Funds", value: 250000, color: "#8246ff" },
  { name: "Loaned Amount", value: 175000, color: "#ffcf10" },
  { name: "Pending Dues", value: 30000, color: "#e11d48" }
];

export function FundsChart() {
  return (
    <Card className="h-full animate-fade-in">
      <CardHeader>
        <CardTitle>Funds Distribution</CardTitle>
        <CardDescription>Overview of Sangam financial status</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                labelLine={false}
                outerRadius={90}
                innerRadius={40}
                fill="#8884d8"
                dataKey="value"
                nameKey="name"
              >
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip 
                formatter={(value) => [`₹${value.toLocaleString()}`, undefined]}
              />
              <Legend 
                layout="vertical" 
                verticalAlign="middle" 
                align="right"
                formatter={(value, entry, index) => (
                  <span className="text-sm font-medium">{value}</span>
                )}
              />
            </PieChart>
          </ResponsiveContainer>
        </div>
        <div className="grid grid-cols-3 gap-4 mt-6">
          {data.map((item, index) => (
            <div key={index} className="text-center">
              <div className="text-lg font-semibold">
                ₹{(item.value/1000).toFixed(0)}K
              </div>
              <div className="text-xs text-muted-foreground">
                {item.name}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
