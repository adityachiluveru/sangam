
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

const data = [
  { month: "Jan", paid: 32, pending: 8 },
  { month: "Feb", paid: 28, pending: 12 },
  { month: "Mar", paid: 35, pending: 5 },
  { month: "Apr", paid: 30, pending: 10 },
  { month: "May", paid: 25, pending: 15 }
];

export function MonthlyPaymentChart() {
  return (
    <Card className="h-full animate-fade-in">
      <CardHeader>
        <CardTitle>Monthly Payment Status</CardTitle>
        <CardDescription>Paid vs. pending members</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={data}
              margin={{
                top: 20,
                right: 30,
                left: 0,
                bottom: 5,
              }}
            >
              <CartesianGrid strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip 
                formatter={(value, name) => [
                  value, 
                  name === 'paid' ? 'Paid Members' : 'Pending Members'
                ]}
              />
              <Bar 
                dataKey="paid" 
                stackId="a" 
                fill="#8246ff" 
                radius={[4, 4, 0, 0]}
                name="Paid"
              />
              <Bar 
                dataKey="pending" 
                stackId="a" 
                fill="#e11d48" 
                radius={[4, 4, 0, 0]} 
                name="Pending"
              />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}
