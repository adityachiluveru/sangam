
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface StatCardProps {
  title: string;
  value: string | number;
  description?: string;
  icon?: React.ReactNode;
  trend?: {
    value: number;
    isPositive: boolean;
  };
  className?: string;
  onClick?: () => void;  // Added onClick prop
}

export function StatCard({
  title,
  value,
  description,
  icon,
  trend,
  className,
  onClick,  // Added onClick prop
}: StatCardProps) {
  return (
    <Card className={cn("hover-scale overflow-hidden", className)} onClick={onClick}>
      <CardContent className={cn("p-6", onClick ? "cursor-pointer" : "")}>
        <div className="flex justify-between items-start">
          <div>
            <p className="text-sm font-medium text-muted-foreground">{title}</p>
            <h3 className="text-2xl font-bold mt-1">{value}</h3>
            {description && (
              <p className="text-sm text-muted-foreground mt-1">{description}</p>
            )}
            {trend && (
              <div className="flex items-center mt-2">
                <span
                  className={cn(
                    "text-xs font-medium",
                    trend.isPositive ? "text-green-600" : "text-red-600"
                  )}
                >
                  {trend.isPositive ? "+" : "-"}{trend.value}%
                </span>
                <span className="text-xs text-muted-foreground ml-1">
                  from last month
                </span>
              </div>
            )}
          </div>
          {icon && (
            <div className="p-2 rounded-full bg-sangam-50">
              {icon}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
