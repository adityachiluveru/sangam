
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";

type ActivityItem = {
  id: string;
  description: string;
  amount?: string;
  type: 'loan' | 'payment' | 'member' | 'other';
  date: string;
  time: string;
};

const sampleActivities: ActivityItem[] = [
  {
    id: '1',
    description: 'Rahul Sharma paid monthly dues',
    amount: '+₹2,500',
    type: 'payment',
    date: '2025-05-09',
    time: '10:30 AM'
  },
  {
    id: '2',
    description: 'New loan issued to Priya Patel',
    amount: '-₹25,000',
    type: 'loan',
    date: '2025-05-09',
    time: '09:15 AM'
  },
  {
    id: '3',
    description: 'Added new member Ananya Singh',
    type: 'member',
    date: '2025-05-08',
    time: '03:45 PM'
  },
  {
    id: '4',
    description: 'Loan fully repaid by Vikram Kapoor',
    amount: '+₹12,000',
    type: 'payment',
    date: '2025-05-08',
    time: '11:20 AM'
  },
  {
    id: '5',
    description: 'Monthly committee meeting scheduled',
    type: 'other',
    date: '2025-05-08',
    time: '09:00 AM'
  },
];

function getActivityIcon(type: ActivityItem['type']) {
  switch (type) {
    case 'loan':
      return <div className="w-2 h-2 rounded-full bg-amber-500" />;
    case 'payment':
      return <div className="w-2 h-2 rounded-full bg-green-500" />;
    case 'member':
      return <div className="w-2 h-2 rounded-full bg-blue-500" />;
    default:
      return <div className="w-2 h-2 rounded-full bg-gray-500" />;
  }
}

export function RecentActivity() {
  return (
    <Card className="h-full">
      <CardHeader>
        <CardTitle>Recent Activity</CardTitle>
        <CardDescription>Latest transactions and events</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4 max-h-[400px] overflow-y-auto pr-2">
        {sampleActivities.map((activity) => (
          <div 
            key={activity.id}
            className="flex items-start p-3 rounded-md transition-colors hover:bg-muted/50"
          >
            <div className="flex items-center justify-center w-8 h-8 rounded-full bg-muted mr-3">
              {getActivityIcon(activity.type)}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium">{activity.description}</p>
              <p className="text-xs text-muted-foreground">
                {new Date(activity.date).toLocaleDateString()} · {activity.time}
              </p>
            </div>
            {activity.amount && (
              <span className={`text-sm font-medium ${activity.amount.startsWith('+') ? 'text-green-600' : 'text-amber-600'}`}>
                {activity.amount}
              </span>
            )}
          </div>
        ))}
      </CardContent>
    </Card>
  );
}
