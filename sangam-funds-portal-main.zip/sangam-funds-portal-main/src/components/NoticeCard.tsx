
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Bell } from "lucide-react";

type Notice = {
  id: string;
  title: string;
  content: string;
  date: string;
  priority: 'low' | 'medium' | 'high';
};

const notices: Notice[] = [
  {
    id: '1',
    title: 'Monthly Meeting',
    content: 'Next meeting scheduled for May 15th, 2025 at Community Hall. Attendance is mandatory for all members.',
    date: '2025-05-09',
    priority: 'high'
  },
  {
    id: '2',
    title: 'Loan Application Deadline',
    content: 'Applications for new loans must be submitted by May 20th for consideration in the next committee meeting.',
    date: '2025-05-08',
    priority: 'medium'
  }
];

function getPriorityBadge(priority: Notice['priority']) {
  switch (priority) {
    case 'high':
      return <span className="px-2 py-1 text-xs font-medium rounded-full bg-red-100 text-red-800">High Priority</span>;
    case 'medium':
      return <span className="px-2 py-1 text-xs font-medium rounded-full bg-amber-100 text-amber-800">Medium</span>;
    case 'low':
      return <span className="px-2 py-1 text-xs font-medium rounded-full bg-blue-100 text-blue-800">Low</span>;
  }
}

export function NoticeCard() {
  return (
    <Card className="h-full animate-fade-in">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-lg font-semibold">Notices & Announcements</CardTitle>
        <Bell className="h-5 w-5 text-sangam-600" />
      </CardHeader>
      <CardContent className="space-y-4">
        {notices.map((notice) => (
          <div 
            key={notice.id}
            className="p-3 rounded-md border border-border transition-all hover:border-sangam-200 hover:shadow-sm"
          >
            <div className="flex justify-between items-center mb-2">
              <h3 className="font-medium">{notice.title}</h3>
              {getPriorityBadge(notice.priority)}
            </div>
            <p className="text-sm text-muted-foreground">{notice.content}</p>
            <p className="text-xs text-muted-foreground mt-2">
              Posted: {new Date(notice.date).toLocaleDateString()}
            </p>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}
