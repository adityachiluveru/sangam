
import { useState, useEffect } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarTrigger
} from "@/components/ui/sidebar";
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { 
  Users, 
  CreditCard, 
  PiggyBank, 
  ClipboardList, 
  BarChart2,
  Bell,
  LogOut,
  Menu,
  User,
  Wallet,
  Globe,
  Settings
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useIsMobile } from '@/hooks/use-mobile';
import { useAuth } from '@/context/AuthContext';
import { useLanguage } from '@/context/LanguageContext';

type MenuItem = {
  icon: React.ElementType;
  labelKey: string;
  path: string;
};

export function AppSidebar() {
  const [isOpen, setIsOpen] = useState(true);
  const isMobile = useIsMobile();
  const { logout, user } = useAuth();
  const { language, setLanguage, t } = useLanguage();
  const navigate = useNavigate();
  
  // Define menu items
  const menuItems: MenuItem[] = [
    { icon: BarChart2, labelKey: 'dashboard', path: '/' },
    { icon: Users, labelKey: 'members', path: '/members' },
    { icon: CreditCard, labelKey: 'loans', path: '/loans' },
    { icon: PiggyBank, labelKey: 'transactions', path: '/transactions' },
    { icon: ClipboardList, labelKey: 'reports', path: '/reports' },
    { icon: Bell, labelKey: 'notices', path: '/notices' },
    { icon: Wallet, labelKey: 'watta', path: '/watta' },
  ];
  
  useEffect(() => {
    if (isMobile) {
      setIsOpen(false);
    } else {
      setIsOpen(true);
    }
  }, [isMobile]);

  const toggleSidebar = () => {
    setIsOpen(!isOpen);
  };

  const handleLogout = () => {
    logout();
  };

  const toggleLanguage = () => {
    setLanguage(language === 'english' ? 'telugu' : 'english');
  };

  const goToProfile = () => {
    navigate('/profile');
  };

  return (
    <div className={cn(
      "h-screen fixed left-0 top-0 z-40 transition-all duration-300 ease-in-out",
      isOpen ? "w-64" : "w-16"
    )}>
      <Sidebar className="border-r border-gray-200 shadow-sm animate-fade-in">
        <SidebarHeader className="px-4 py-5 flex items-center justify-between">
          <div className={cn(
            "flex items-center transition-all duration-300",
            isOpen ? "justify-start" : "justify-center"
          )}>
            {isOpen ? (
              <div className="flex items-center">
                <PiggyBank className="h-6 w-6 text-sangam-600" />
                <span className="ml-2 text-lg font-bold text-sangam-800 animate-fade-in">Sangam Portal</span>
              </div>
            ) : (
              <PiggyBank className="h-6 w-6 text-sangam-600 animate-pulse-in" />
            )}
          </div>
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={toggleSidebar} 
            className="h-8 w-8 transition-transform hover:bg-sangam-50"
          >
            <Menu className="h-4 w-4" />
          </Button>
        </SidebarHeader>
        
        <SidebarContent>
          <div className="px-3 py-2">
            {isOpen && (
              <div className="mb-6 px-2 animate-fade-in">
                <div 
                  className="flex items-center space-x-3 py-3 px-2 rounded-md hover:bg-sangam-50 transition-colors cursor-pointer"
                  onClick={goToProfile}
                >
                  <Avatar className="h-10 w-10 border-2 border-sangam-200 shadow-sm hover:shadow transition-all">
                    <AvatarFallback className="bg-sangam-100 text-sangam-600">
                      {user?.username ? user?.username[0].toUpperCase() : 'A'}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="text-sm font-medium">{user?.username || 'Admin User'}</p>
                    <p className="text-xs text-muted-foreground">admin@sangam.com</p>
                  </div>
                </div>
              </div>
            )}
            
            <div className="space-y-1">
              {menuItems.map((item) => (
                <NavLink
                  key={item.path}
                  to={item.path}
                  className={({ isActive }) => cn(
                    "flex items-center py-2 px-3 rounded-md text-sm transition-colors",
                    isActive 
                      ? "bg-sangam-50 text-sangam-800 font-medium" 
                      : "text-muted-foreground hover:bg-sangam-50 hover:text-sangam-800",
                    !isOpen && "justify-center",
                    "transition-transform hover:translate-x-1"
                  )}
                >
                  {isOpen ? (
                    <>
                      <item.icon className="h-5 w-5 mr-2" />
                      <span className="animate-fade-in">{t(item.labelKey)}</span>
                    </>
                  ) : (
                    <TooltipProvider>
                      <Tooltip delayDuration={300}>
                        <TooltipTrigger asChild>
                          <item.icon className="h-5 w-5" />
                        </TooltipTrigger>
                        <TooltipContent side="right">
                          <p>{t(item.labelKey)}</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  )}
                </NavLink>
              ))}
            </div>
          </div>
        </SidebarContent>
        
        <SidebarFooter className="px-3 py-4">
          <Button 
            variant="ghost" 
            onClick={toggleLanguage}
            className={cn(
              "w-full mb-2 justify-start text-muted-foreground hover:bg-sangam-50 hover:text-sangam-800 transition-colors",
              !isOpen && "justify-center"
            )}
          >
            {isOpen ? (
              <>
                <Globe className="h-5 w-5 mr-2" />
                <span>{language === 'english' ? 'తెలుగు' : 'English'}</span>
              </>
            ) : (
              <TooltipProvider>
                <Tooltip delayDuration={300}>
                  <TooltipTrigger asChild>
                    <Globe className="h-5 w-5" />
                  </TooltipTrigger>
                  <TooltipContent side="right">
                    <p>{language === 'english' ? 'Switch to Telugu' : 'Switch to English'}</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            )}
          </Button>
          
          <Button 
            variant="ghost" 
            onClick={goToProfile}
            className={cn(
              "w-full mb-2 justify-start text-muted-foreground hover:bg-sangam-50 hover:text-sangam-800 transition-colors",
              !isOpen && "justify-center"
            )}
          >
            {isOpen ? (
              <>
                <Settings className="h-5 w-5 mr-2" />
                <span>{t('profile')}</span>
              </>
            ) : (
              <TooltipProvider>
                <Tooltip delayDuration={300}>
                  <TooltipTrigger asChild>
                    <Settings className="h-5 w-5" />
                  </TooltipTrigger>
                  <TooltipContent side="right">
                    <p>{t('profile')}</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            )}
          </Button>

          <Button 
            variant="ghost" 
            onClick={handleLogout}
            className={cn(
              "w-full justify-start text-muted-foreground hover:bg-sangam-50 hover:text-sangam-800 transition-colors",
              !isOpen && "justify-center"
            )}
          >
            {isOpen ? (
              <>
                <LogOut className="h-5 w-5 mr-2" />
                <span>{t('logout')}</span>
              </>
            ) : (
              <TooltipProvider>
                <Tooltip delayDuration={300}>
                  <TooltipTrigger asChild>
                    <LogOut className="h-5 w-5" />
                  </TooltipTrigger>
                  <TooltipContent side="right">
                    <p>{t('logout')}</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            )}
          </Button>
        </SidebarFooter>
      </Sidebar>
    </div>
  );
}
