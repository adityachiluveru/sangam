
import { SidebarProvider } from '@/components/ui/sidebar';
import { AppSidebar } from '@/components/AppSidebar';
import React, { useState } from 'react';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { PlusCircle, Bell, Edit, Trash2, Check, Info, Search } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

type NoticeType = {
  id: number;
  title: string;
  message: string;
  date: string;
  expiryDate: string;
  priority: 'High' | 'Medium' | 'Low';
  status: 'Active' | 'Expired' | 'Scheduled';
};

const dummyNotices: NoticeType[] = [
  {
    id: 1,
    title: 'Monthly Meeting',
    message: 'The monthly sangam meeting will be held on Sunday at 10:00 AM in the community hall. All members are requested to attend.',
    date: '2025-05-01',
    expiryDate: '2025-05-10',
    priority: 'High',
    status: 'Active'
  },
  {
    id: 2,
    title: 'New Loan Scheme',
    message: 'A new low-interest loan scheme has been launched for small businesses. Interested members can contact the secretary for more details.',
    date: '2025-04-25',
    expiryDate: '2025-06-25',
    priority: 'Medium',
    status: 'Active'
  },
  {
    id: 3,
    title: 'Pending Dues Reminder',
    message: 'Members with pending dues are requested to clear their payments before the end of the month to avoid late fees.',
    date: '2025-04-20',
    expiryDate: '2025-04-30',
    priority: 'High',
    status: 'Expired'
  },
  {
    id: 4,
    title: 'Festival Celebration',
    message: 'The sangam will be organizing a cultural event for the upcoming festival. Members interested in volunteering can register with the cultural committee.',
    date: '2025-04-15',
    expiryDate: '2025-05-15',
    priority: 'Medium',
    status: 'Active'
  },
  {
    id: 5,
    title: 'Annual General Meeting',
    message: 'The Annual General Meeting will be held next month. The agenda and venue details will be shared soon.',
    date: '2025-04-10',
    expiryDate: '2025-06-10',
    priority: 'Low',
    status: 'Scheduled'
  }
];

const Notices = () => {
  const [notices, setNotices] = useState<NoticeType[]>(dummyNotices);
  const [activeFilter, setActiveFilter] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState("");
  const [isAddNoticeOpen, setIsAddNoticeOpen] = useState(false);
  const [noticeToDelete, setNoticeToDelete] = useState<number | null>(null);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isViewDetailsOpen, setIsViewDetailsOpen] = useState(false);
  const [viewingNotice, setViewingNotice] = useState<NoticeType | null>(null);
  const [isEditNoticeOpen, setIsEditNoticeOpen] = useState(false);
  const [editingNotice, setEditingNotice] = useState<NoticeType | null>(null);
  const [newNotice, setNewNotice] = useState<Omit<NoticeType, 'id'>>({
    title: '',
    message: '',
    date: new Date().toISOString().split('T')[0],
    expiryDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    priority: 'Medium',
    status: 'Active'
  });

  const searchedNotices = notices.filter(notice => 
    notice.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    notice.message.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredNotices = activeFilter === 'all' 
    ? searchedNotices 
    : searchedNotices.filter(notice => notice.status.toLowerCase() === activeFilter.toLowerCase());

  const getPriorityColor = (priority: string) => {
    switch(priority.toLowerCase()) {
      case 'high':
        return 'bg-red-100 text-red-800';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800';
      case 'low':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusColor = (status: string) => {
    switch(status.toLowerCase()) {
      case 'active':
        return 'bg-green-100 text-green-800';
      case 'expired':
        return 'bg-gray-100 text-gray-800';
      case 'scheduled':
        return 'bg-purple-100 text-purple-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const handleAddNotice = () => {
    if (!newNotice.title || !newNotice.message) {
      toast.error("Title and message are required");
      return;
    }

    const id = Math.max(0, ...notices.map(n => n.id)) + 1;
    setNotices([...notices, { ...newNotice, id }]);
    setIsAddNoticeOpen(false);
    toast.success("New notice added successfully");

    // Reset form
    setNewNotice({
      title: '',
      message: '',
      date: new Date().toISOString().split('T')[0],
      expiryDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      priority: 'Medium',
      status: 'Active'
    });
  };

  const handleDeleteNotice = () => {
    if (noticeToDelete === null) return;
    
    setNotices(notices.filter(notice => notice.id !== noticeToDelete));
    setIsDeleteDialogOpen(false);
    setNoticeToDelete(null);
    toast.success("Notice deleted successfully");
  };

  const confirmDelete = (id: number) => {
    setNoticeToDelete(id);
    setIsDeleteDialogOpen(true);
  };

  const handleViewNotice = (notice: NoticeType) => {
    setViewingNotice(notice);
    setIsViewDetailsOpen(true);
  };

  const handleEditNotice = (notice: NoticeType) => {
    setEditingNotice({...notice});
    setIsEditNoticeOpen(true);
  };

  const handleUpdateNotice = () => {
    if (!editingNotice) return;
    
    setNotices(notices.map(notice => 
      notice.id === editingNotice.id ? editingNotice : notice
    ));
    
    setIsEditNoticeOpen(false);
    toast.success("Notice updated successfully");
  };

  const handleMarkAsRead = (id: number) => {
    toast.success("Notice marked as read");
  };

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full">
        <AppSidebar />
        <div className="flex-1 pl-16 md:pl-64">
          <div className="p-6 max-w-7xl mx-auto animate-fade-in">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
              <div>
                <h1 className="text-2xl font-bold">Notices & Announcements</h1>
                <p className="text-muted-foreground">Manage community notifications</p>
              </div>
              <Dialog open={isAddNoticeOpen} onOpenChange={setIsAddNoticeOpen}>
                <DialogTrigger asChild>
                  <Button className="flex items-center gap-2">
                    <PlusCircle size={16} />
                    <span>Create Notice</span>
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[525px]">
                  <DialogHeader>
                    <DialogTitle>Create New Notice</DialogTitle>
                    <DialogDescription>
                      Create a new notice or announcement for the community
                    </DialogDescription>
                  </DialogHeader>
                  <div className="grid gap-4 py-4">
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="title" className="text-right">
                        Title
                      </Label>
                      <Input
                        id="title"
                        value={newNotice.title}
                        onChange={(e) => setNewNotice({...newNotice, title: e.target.value})}
                        className="col-span-3"
                        placeholder="Enter notice title"
                      />
                    </div>
                    <div className="grid grid-cols-4 items-start gap-4">
                      <Label htmlFor="message" className="text-right pt-2">
                        Message
                      </Label>
                      <Textarea
                        id="message"
                        value={newNotice.message}
                        onChange={(e) => setNewNotice({...newNotice, message: e.target.value})}
                        className="col-span-3"
                        placeholder="Enter notice details"
                        rows={4}
                      />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="priority" className="text-right">
                        Priority
                      </Label>
                      <Select 
                        value={newNotice.priority} 
                        onValueChange={(value) => setNewNotice({...newNotice, priority: value as 'High' | 'Medium' | 'Low'})}
                      >
                        <SelectTrigger className="col-span-3">
                          <SelectValue placeholder="Select priority level" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="High">High</SelectItem>
                          <SelectItem value="Medium">Medium</SelectItem>
                          <SelectItem value="Low">Low</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="status" className="text-right">
                        Status
                      </Label>
                      <Select 
                        value={newNotice.status} 
                        onValueChange={(value) => setNewNotice({...newNotice, status: value as 'Active' | 'Expired' | 'Scheduled'})}
                      >
                        <SelectTrigger className="col-span-3">
                          <SelectValue placeholder="Select notice status" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Active">Active</SelectItem>
                          <SelectItem value="Scheduled">Scheduled</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="expiryDate" className="text-right">
                        Expiry Date
                      </Label>
                      <Input
                        id="expiryDate"
                        type="date"
                        value={newNotice.expiryDate}
                        onChange={(e) => setNewNotice({...newNotice, expiryDate: e.target.value})}
                        className="col-span-3"
                      />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setIsAddNoticeOpen(false)}>Cancel</Button>
                    <Button onClick={handleAddNotice}>Create Notice</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
            
            <div className="mb-6">
              <div className="flex flex-col sm:flex-row sm:items-center gap-4 mb-6">
                <div className="flex space-x-2">
                  <Button 
                    variant={activeFilter === 'all' ? 'default' : 'outline'} 
                    size="sm"
                    onClick={() => setActiveFilter('all')}
                  >
                    All
                  </Button>
                  <Button 
                    variant={activeFilter === 'active' ? 'default' : 'outline'} 
                    size="sm"
                    onClick={() => setActiveFilter('active')}
                  >
                    Active
                  </Button>
                  <Button 
                    variant={activeFilter === 'scheduled' ? 'default' : 'outline'} 
                    size="sm"
                    onClick={() => setActiveFilter('scheduled')}
                  >
                    Scheduled
                  </Button>
                  <Button 
                    variant={activeFilter === 'expired' ? 'default' : 'outline'} 
                    size="sm"
                    onClick={() => setActiveFilter('expired')}
                  >
                    Expired
                  </Button>
                </div>
                <div className="relative flex-1">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search notices..."
                    className="pl-8"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {filteredNotices.map((notice) => (
                  <Card key={notice.id} className="overflow-hidden">
                    <CardHeader className="pb-2">
                      <div className="flex items-start justify-between">
                        <div className="flex items-center gap-2">
                          <Bell size={16} className="text-muted-foreground mt-1" />
                          <div>
                            <CardTitle className="cursor-pointer hover:text-primary" onClick={() => handleViewNotice(notice)}>
                              {notice.title}
                            </CardTitle>
                            <CardDescription className="text-xs">
                              Posted: {new Date(notice.date).toLocaleDateString()} • Expires: {new Date(notice.expiryDate).toLocaleDateString()}
                            </CardDescription>
                          </div>
                        </div>
                        <div className="flex gap-1">
                          <Badge variant="outline" className={getPriorityColor(notice.priority)}>
                            {notice.priority}
                          </Badge>
                          <Badge variant="outline" className={getStatusColor(notice.status)}>
                            {notice.status}
                          </Badge>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm">{notice.message}</p>
                    </CardContent>
                    <CardFooter className="bg-muted/20 flex justify-end gap-2 py-2">
                      {notice.status !== 'Expired' && (
                        <Button variant="ghost" size="sm" className="flex items-center gap-1" onClick={() => handleMarkAsRead(notice.id)}>
                          <Check size={14} />
                          <span>Mark as Read</span>
                        </Button>
                      )}
                      <Button variant="ghost" size="icon" onClick={() => handleEditNotice(notice)}>
                        <Edit size={14} />
                      </Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <Trash2 size={14} />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Delete Notice</AlertDialogTitle>
                            <AlertDialogDescription>
                              Are you sure you want to delete this notice? This action cannot be undone.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction 
                              className="bg-red-600 hover:bg-red-700"
                              onClick={() => confirmDelete(notice.id)}
                            >
                              Delete
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </CardFooter>
                  </Card>
                ))}
              </div>
              
              {filteredNotices.length === 0 && (
                <div className="text-center py-12">
                  <Bell size={48} className="mx-auto text-muted-foreground" />
                  <h3 className="mt-4 text-lg font-medium">No notices found</h3>
                  <p className="text-muted-foreground">
                    {activeFilter === 'all' 
                      ? 'There are no notices to display.' 
                      : `There are no ${activeFilter} notices to display.`}
                  </p>
                </div>
              )}
            </div>

            {/* View Notice Details */}
            <Dialog open={isViewDetailsOpen} onOpenChange={setIsViewDetailsOpen}>
              <DialogContent className="sm:max-w-[600px]">
                {viewingNotice && (
                  <>
                    <DialogHeader>
                      <div className="flex items-center justify-between">
                        <DialogTitle>{viewingNotice.title}</DialogTitle>
                        <div className="flex gap-1">
                          <Badge variant="outline" className={getPriorityColor(viewingNotice.priority)}>
                            {viewingNotice.priority}
                          </Badge>
                          <Badge variant="outline" className={getStatusColor(viewingNotice.status)}>
                            {viewingNotice.status}
                          </Badge>
                        </div>
                      </div>
                      <DialogDescription>
                        Posted: {new Date(viewingNotice.date).toLocaleDateString()} • 
                        Expires: {new Date(viewingNotice.expiryDate).toLocaleDateString()}
                      </DialogDescription>
                    </DialogHeader>
                    <div className="py-4">
                      <div className="prose">
                        <p>{viewingNotice.message}</p>
                      </div>
                      
                      {viewingNotice.status === 'Active' && (
                        <div className="mt-6 p-4 bg-blue-50 rounded-md flex items-start">
                          <Info className="text-blue-500 mr-2 mt-0.5" size={18} />
                          <div>
                            <h4 className="font-medium text-blue-700">Notice Information</h4>
                            <p className="text-sm text-blue-600">
                              This notice is currently active and visible to all members.
                            </p>
                          </div>
                        </div>
                      )}

                      {viewingNotice.status === 'Scheduled' && (
                        <div className="mt-6 p-4 bg-purple-50 rounded-md flex items-start">
                          <Info className="text-purple-500 mr-2 mt-0.5" size={18} />
                          <div>
                            <h4 className="font-medium text-purple-700">Scheduled Notice</h4>
                            <p className="text-sm text-purple-600">
                              This notice is scheduled and will be automatically published on the date specified.
                            </p>
                          </div>
                        </div>
                      )}
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => {
                        handleEditNotice(viewingNotice);
                        setIsViewDetailsOpen(false);
                      }}>
                        <Edit className="h-4 w-4 mr-2" />
                        Edit
                      </Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="destructive">
                            <Trash2 className="h-4 w-4 mr-2" />
                            Delete
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Delete Notice</AlertDialogTitle>
                            <AlertDialogDescription>
                              Are you sure you want to delete this notice? This action cannot be undone.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction 
                              className="bg-red-600 hover:bg-red-700"
                              onClick={() => {
                                confirmDelete(viewingNotice.id);
                                setIsViewDetailsOpen(false);
                              }}
                            >
                              Delete
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </DialogFooter>
                  </>
                )}
              </DialogContent>
            </Dialog>

            {/* Edit Notice */}
            <Dialog open={isEditNoticeOpen} onOpenChange={setIsEditNoticeOpen}>
              <DialogContent className="sm:max-w-[525px]">
                {editingNotice && (
                  <>
                    <DialogHeader>
                      <DialogTitle>Edit Notice</DialogTitle>
                      <DialogDescription>
                        Update notice details
                      </DialogDescription>
                    </DialogHeader>
                    <div className="grid gap-4 py-4">
                      <div className="grid grid-cols-4 items-center gap-4">
                        <Label htmlFor="edit-title" className="text-right">
                          Title
                        </Label>
                        <Input
                          id="edit-title"
                          value={editingNotice.title}
                          onChange={(e) => setEditingNotice({...editingNotice, title: e.target.value})}
                          className="col-span-3"
                        />
                      </div>
                      <div className="grid grid-cols-4 items-start gap-4">
                        <Label htmlFor="edit-message" className="text-right pt-2">
                          Message
                        </Label>
                        <Textarea
                          id="edit-message"
                          value={editingNotice.message}
                          onChange={(e) => setEditingNotice({...editingNotice, message: e.target.value})}
                          className="col-span-3"
                          rows={4}
                        />
                      </div>
                      <div className="grid grid-cols-4 items-center gap-4">
                        <Label htmlFor="edit-priority" className="text-right">
                          Priority
                        </Label>
                        <Select 
                          value={editingNotice.priority} 
                          onValueChange={(value) => setEditingNotice({...editingNotice, priority: value as 'High' | 'Medium' | 'Low'})}
                        >
                          <SelectTrigger className="col-span-3">
                            <SelectValue placeholder="Select priority level" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="High">High</SelectItem>
                            <SelectItem value="Medium">Medium</SelectItem>
                            <SelectItem value="Low">Low</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="grid grid-cols-4 items-center gap-4">
                        <Label htmlFor="edit-status" className="text-right">
                          Status
                        </Label>
                        <Select 
                          value={editingNotice.status} 
                          onValueChange={(value) => setEditingNotice({...editingNotice, status: value as 'Active' | 'Expired' | 'Scheduled'})}
                        >
                          <SelectTrigger className="col-span-3">
                            <SelectValue placeholder="Select notice status" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Active">Active</SelectItem>
                            <SelectItem value="Expired">Expired</SelectItem>
                            <SelectItem value="Scheduled">Scheduled</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="grid grid-cols-4 items-center gap-4">
                        <Label htmlFor="edit-expiryDate" className="text-right">
                          Expiry Date
                        </Label>
                        <Input
                          id="edit-expiryDate"
                          type="date"
                          value={editingNotice.expiryDate}
                          onChange={(e) => setEditingNotice({...editingNotice, expiryDate: e.target.value})}
                          className="col-span-3"
                        />
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setIsEditNoticeOpen(false)}>Cancel</Button>
                      <Button onClick={handleUpdateNotice}>Update Notice</Button>
                    </DialogFooter>
                  </>
                )}
              </DialogContent>
            </Dialog>

            {/* Delete Notice Dialog */}
            <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Confirm Deletion</AlertDialogTitle>
                  <AlertDialogDescription>
                    Are you sure you want to delete this notice? This action cannot be undone.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel onClick={() => setNoticeToDelete(null)}>Cancel</AlertDialogCancel>
                  <AlertDialogAction 
                    className="bg-red-600 hover:bg-red-700"
                    onClick={handleDeleteNotice}
                  >
                    Delete
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </div>
      </div>
    </SidebarProvider>
  );
};

export default Notices;
