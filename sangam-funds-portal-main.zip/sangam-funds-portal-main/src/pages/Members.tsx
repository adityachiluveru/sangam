
import { useState } from "react";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle,
  CardDescription, 
  CardFooter 
} from "@/components/ui/card";
import { 
  Table, 
  TableHeader, 
  TableBody, 
  TableRow, 
  TableHead, 
  TableCell 
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { 
  Search, 
  Plus, 
  Edit, 
  Trash2,
  UserPlus,
  Eye,
  Filter,
  Download,
  Phone,
  Briefcase,
  MapPin,
  Calendar,
  CreditCard,
  ChevronLeft,
  ChevronRight
} from "lucide-react";
import { SidebarProvider } from '@/components/ui/sidebar';
import { AppSidebar } from '@/components/AppSidebar';
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

type Member = {
  id: string; 
  name: string;
  mobile: string;
  occupation: string;
  address: string;
  dob: string;
  role: 'Member' | 'Treasurer' | 'Chairman';
  joinDate: string;
};

type LoanRecord = {
  id: string;
  amount: string;
  purpose: string;
  issueDate: string;
  installment: string;
  paidAmount: string;
  balance: string;
  status: 'active' | 'completed';
};

type PaymentRecord = {
  id: string;
  date: string;
  amount: string;
  type: 'loan' | 'dues';
  method: 'cash' | 'upi' | 'bank';
};

// Sample member data
const initialMembers: Member[] = [
  { 
    id: '1', 
    name: 'Rahul Sharma', 
    mobile: '9876543210', 
    occupation: 'Software Engineer', 
    address: 'Mumbai, Maharashtra', 
    dob: '1985-04-12', 
    role: 'Member',
    joinDate: '2022-01-15' 
  },
  { 
    id: '2', 
    name: 'Priya Patel', 
    mobile: '8765432109', 
    occupation: 'Doctor', 
    address: 'Pune, Maharashtra', 
    dob: '1982-08-23', 
    role: 'Treasurer',
    joinDate: '2022-01-10' 
  },
  { 
    id: '3', 
    name: 'Amit Singh', 
    mobile: '7654321098', 
    occupation: 'Business Owner', 
    address: 'Nagpur, Maharashtra', 
    dob: '1979-11-05', 
    role: 'Chairman',
    joinDate: '2022-01-01' 
  },
  { 
    id: '4', 
    name: 'Sunita Desai', 
    mobile: '6543210987', 
    occupation: 'Teacher', 
    address: 'Nashik, Maharashtra', 
    dob: '1990-02-18', 
    role: 'Member',
    joinDate: '2022-02-20' 
  },
  { 
    id: '5', 
    name: 'Vikram Kapoor', 
    mobile: '9876543211', 
    occupation: 'Accountant', 
    address: 'Thane, Maharashtra', 
    dob: '1988-07-30', 
    role: 'Member',
    joinDate: '2022-03-05' 
  },
];

// Sample loan data for the member details
const sampleLoans: Record<string, LoanRecord[]> = {
  '1': [
    { 
      id: 'L1', 
      amount: '₹25,000', 
      purpose: 'Home Renovation', 
      issueDate: '2022-04-10',
      installment: '₹2,500',
      paidAmount: '₹10,000',
      balance: '₹15,000',
      status: 'active'
    },
  ],
  '2': [
    { 
      id: 'L2', 
      amount: '₹15,000', 
      purpose: 'Medical Expenses', 
      issueDate: '2022-05-12',
      installment: '₹1,500',
      paidAmount: '₹15,000',
      balance: '₹0',
      status: 'completed'
    },
  ],
  '4': [
    { 
      id: 'L3', 
      amount: '₹50,000', 
      purpose: 'Education Fees', 
      issueDate: '2022-06-15',
      installment: '₹5,000',
      paidAmount: '₹25,000',
      balance: '₹25,000',
      status: 'active'
    },
  ],
};

// Sample payment data for the member details
const samplePayments: Record<string, PaymentRecord[]> = {
  '1': [
    { id: 'P1', date: '2022-05-10', amount: '₹2,500', type: 'loan', method: 'upi' },
    { id: 'P2', date: '2022-06-10', amount: '₹2,500', type: 'loan', method: 'cash' },
    { id: 'P3', date: '2022-07-10', amount: '₹2,500', type: 'loan', method: 'cash' },
    { id: 'P4', date: '2022-08-10', amount: '₹2,500', type: 'loan', method: 'upi' },
    { id: 'P5', date: '2022-04-05', amount: '₹1,000', type: 'dues', method: 'cash' },
    { id: 'P6', date: '2022-05-05', amount: '₹1,000', type: 'dues', method: 'cash' },
  ],
  '2': [
    { id: 'P7', date: '2022-06-12', amount: '₹1,500', type: 'loan', method: 'bank' },
    { id: 'P8', date: '2022-07-12', amount: '₹1,500', type: 'loan', method: 'bank' },
    { id: 'P9', date: '2022-08-12', amount: '₹1,500', type: 'loan', method: 'upi' },
    { id: 'P10', date: '2022-04-05', amount: '₹1,000', type: 'dues', method: 'cash' },
  ],
  '4': [
    { id: 'P11', date: '2022-07-15', amount: '₹5,000', type: 'loan', method: 'upi' },
    { id: 'P12', date: '2022-08-15', amount: '₹5,000', type: 'loan', method: 'bank' },
    { id: 'P13', date: '2022-09-15', amount: '₹5,000', type: 'loan', method: 'bank' },
    { id: 'P14', date: '2022-10-15', amount: '₹5,000', type: 'loan', method: 'cash' },
    { id: 'P15', date: '2022-11-15', amount: '₹5,000', type: 'loan', method: 'upi' },
  ],
};

export default function Members() {
  const [members, setMembers] = useState<Member[]>(initialMembers);
  const [searchTerm, setSearchTerm] = useState("");
  const [isAddMemberOpen, setIsAddMemberOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [memberToDelete, setMemberToDelete] = useState<string | null>(null);
  const [viewMember, setViewMember] = useState<Member | null>(null);
  const [isViewDetailsOpen, setIsViewDetailsOpen] = useState(false);
  const [isEditMemberOpen, setIsEditMemberOpen] = useState(false);
  const [editingMember, setEditingMember] = useState<Member | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedRoleFilter, setSelectedRoleFilter] = useState<string | null>(null);
  const [newMember, setNewMember] = useState<Omit<Member, 'id'>>({
    name: '',
    mobile: '',
    occupation: '',
    address: '',
    dob: '',
    role: 'Member',
    joinDate: new Date().toISOString().split('T')[0]
  });
  const [showFilterOptions, setShowFilterOptions] = useState(false);

  const itemsPerPage = 4;

  const filteredMembersByRole = selectedRoleFilter
    ? members.filter(member => member.role === selectedRoleFilter)
    : members;

  const filteredMembers = filteredMembersByRole.filter(member =>
    member.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    member.mobile.includes(searchTerm) ||
    member.occupation.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const paginatedMembers = filteredMembers.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const totalPages = Math.ceil(filteredMembers.length / itemsPerPage);

  const handleAddMember = () => {
    if (!newMember.name || !newMember.mobile) {
      toast.error('Name and mobile number are required');
      return;
    }
    
    const id = (parseInt(members[members.length - 1]?.id || "0") + 1).toString();
    
    setMembers([...members, {...newMember, id}]);
    setIsAddMemberOpen(false);
    toast.success(`Member ${newMember.name} added successfully`);
    
    // Reset form
    setNewMember({
      name: '',
      mobile: '',
      occupation: '',
      address: '',
      dob: '',
      role: 'Member',
      joinDate: new Date().toISOString().split('T')[0]
    });
  };

  const handleDeleteMember = () => {
    if (!memberToDelete) return;
    
    const memberName = members.find(m => m.id === memberToDelete)?.name;
    setMembers(members.filter(member => member.id !== memberToDelete));
    setMemberToDelete(null);
    setIsDeleteDialogOpen(false);
    
    toast.success(`Member ${memberName} has been removed`);
  };

  const confirmDelete = (id: string) => {
    setMemberToDelete(id);
    setIsDeleteDialogOpen(true);
  };

  const handleViewMember = (id: string) => {
    const member = members.find(m => m.id === id);
    if (member) {
      setViewMember(member);
      setIsViewDetailsOpen(true);
    }
  };

  const handleEditMember = (id: string) => {
    const member = members.find(m => m.id === id);
    if (member) {
      setEditingMember({...member});
      setIsEditMemberOpen(true);
    }
  };

  const handleUpdateMember = () => {
    if (!editingMember) return;
    
    setMembers(members.map(member => 
      member.id === editingMember.id ? editingMember : member
    ));
    
    setIsEditMemberOpen(false);
    toast.success(`Member ${editingMember.name} updated successfully`);
  };

  const handleExportMemberList = () => {
    toast.success("Member list exported successfully");
  };

  const handleMarkAsRead = (notificationId: string) => {
    toast.success("Notification marked as read");
  };

  const handleAddPayment = (memberId: string) => {
    toast.success("Payment option will be available soon");
  };

  const getMemberLoans = (memberId: string) => {
    return sampleLoans[memberId] || [];
  };
  
  const getMemberPayments = (memberId: string) => {
    return samplePayments[memberId] || [];
  };

  const handleRoleFilter = (role: string | null) => {
    setSelectedRoleFilter(role);
    setCurrentPage(1);
    setShowFilterOptions(false);
  };

  const nextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };

  const prevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full">
        <AppSidebar />
        <div className="flex-1 pl-16 md:pl-64">
          <div className="p-6 max-w-7xl mx-auto animate-fade-in">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
              <div>
                <h1 className="text-2xl font-bold">Members</h1>
                <p className="text-muted-foreground">Manage Sangam community members</p>
              </div>
              <div className="flex gap-2">
                <Dialog open={isAddMemberOpen} onOpenChange={setIsAddMemberOpen}>
                  <DialogTrigger asChild>
                    <Button className="bg-sangam-600 hover:bg-sangam-700">
                      <UserPlus className="h-4 w-4 mr-2" />
                      Add Member
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-[525px]">
                    <DialogHeader>
                      <DialogTitle>Add New Member</DialogTitle>
                      <DialogDescription>
                        Fill in the details to add a new community member
                      </DialogDescription>
                    </DialogHeader>
                    <div className="grid gap-4 py-4">
                      <div className="grid grid-cols-4 items-center gap-4">
                        <Label htmlFor="name" className="text-right">
                          Full Name
                        </Label>
                        <Input
                          id="name"
                          value={newMember.name}
                          onChange={(e) => setNewMember({...newMember, name: e.target.value})}
                          className="col-span-3"
                          placeholder="Enter member's full name"
                        />
                      </div>
                      <div className="grid grid-cols-4 items-center gap-4">
                        <Label htmlFor="mobile" className="text-right">
                          Mobile
                        </Label>
                        <Input
                          id="mobile"
                          value={newMember.mobile}
                          onChange={(e) => setNewMember({...newMember, mobile: e.target.value})}
                          className="col-span-3"
                          placeholder="10-digit mobile number"
                        />
                      </div>
                      <div className="grid grid-cols-4 items-center gap-4">
                        <Label htmlFor="occupation" className="text-right">
                          Occupation
                        </Label>
                        <Input
                          id="occupation"
                          value={newMember.occupation}
                          onChange={(e) => setNewMember({...newMember, occupation: e.target.value})}
                          className="col-span-3"
                          placeholder="Enter occupation"
                        />
                      </div>
                      <div className="grid grid-cols-4 items-center gap-4">
                        <Label htmlFor="address" className="text-right">
                          Address
                        </Label>
                        <Input
                          id="address"
                          value={newMember.address}
                          onChange={(e) => setNewMember({...newMember, address: e.target.value})}
                          className="col-span-3"
                          placeholder="Enter address"
                        />
                      </div>
                      <div className="grid grid-cols-4 items-center gap-4">
                        <Label htmlFor="dob" className="text-right">
                          Date of Birth
                        </Label>
                        <Input
                          id="dob"
                          type="date"
                          value={newMember.dob}
                          onChange={(e) => setNewMember({...newMember, dob: e.target.value})}
                          className="col-span-3"
                        />
                      </div>
                      <div className="grid grid-cols-4 items-center gap-4">
                        <Label htmlFor="role" className="text-right">
                          Role
                        </Label>
                        <select
                          id="role"
                          value={newMember.role}
                          onChange={(e) => setNewMember({...newMember, role: e.target.value as Member['role']})}
                          className="col-span-3 flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                        >
                          <option value="Member">Member</option>
                          <option value="Treasurer">Treasurer</option>
                          <option value="Chairman">Chairman</option>
                        </select>
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setIsAddMemberOpen(false)}>Cancel</Button>
                      <Button onClick={handleAddMember} className="bg-sangam-600 hover:bg-sangam-700">Add Member</Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>

                <Button variant="outline" onClick={handleExportMemberList}>
                  <Download className="h-4 w-4 mr-2" />
                  Export
                </Button>
              </div>
            </div>
            
            <Card className="mb-6">
              <CardHeader className="pb-3">
                <CardTitle>Member Directory</CardTitle>
                <CardDescription>A list of all members in the Sangam community</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col sm:flex-row sm:items-center gap-4 mb-6">
                  <div className="relative flex-1">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search members..."
                      className="pl-8"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>
                  <div className="flex items-center gap-2 relative">
                    <Button 
                      variant="outline" 
                      className="gap-1"
                      onClick={() => setShowFilterOptions(!showFilterOptions)}
                    >
                      <Filter className="h-4 w-4 mr-1" />
                      {selectedRoleFilter || "All Roles"}
                    </Button>
                    
                    {showFilterOptions && (
                      <div className="absolute top-full mt-2 right-0 w-48 bg-white border rounded-md shadow-lg z-10 py-1">
                        <button 
                          className="w-full text-left px-4 py-2 hover:bg-muted/50 text-sm"
                          onClick={() => handleRoleFilter(null)}
                        >
                          All Roles
                        </button>
                        <button 
                          className="w-full text-left px-4 py-2 hover:bg-muted/50 text-sm"
                          onClick={() => handleRoleFilter('Member')}
                        >
                          Member
                        </button>
                        <button 
                          className="w-full text-left px-4 py-2 hover:bg-muted/50 text-sm"
                          onClick={() => handleRoleFilter('Treasurer')}
                        >
                          Treasurer
                        </button>
                        <button 
                          className="w-full text-left px-4 py-2 hover:bg-muted/50 text-sm"
                          onClick={() => handleRoleFilter('Chairman')}
                        >
                          Chairman
                        </button>
                      </div>
                    )}
                  </div>
                </div>
                
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Mobile</TableHead>
                        <TableHead className="hidden md:table-cell">Occupation</TableHead>
                        <TableHead className="hidden lg:table-cell">Address</TableHead>
                        <TableHead className="hidden lg:table-cell">Role</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {paginatedMembers.map((member) => (
                        <TableRow key={member.id} className="hover:bg-muted/50">
                          <TableCell className="font-medium">{member.name}</TableCell>
                          <TableCell>{member.mobile}</TableCell>
                          <TableCell className="hidden md:table-cell">{member.occupation}</TableCell>
                          <TableCell className="hidden lg:table-cell">{member.address}</TableCell>
                          <TableCell className="hidden lg:table-cell">
                            <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                              member.role === 'Chairman' ? 'bg-sangam-100 text-sangam-800' : 
                              member.role === 'Treasurer' ? 'bg-amber-100 text-amber-800' : 
                              'bg-blue-100 text-blue-800'
                            }`}>
                              {member.role}
                            </span>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                className="h-8 w-8"
                                onClick={() => handleViewMember(member.id)}
                              >
                                <Eye className="h-4 w-4" />
                              </Button>
                              
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                className="h-8 w-8"
                                onClick={() => handleEditMember(member.id)}
                              >
                                <Edit className="h-4 w-4" />
                              </Button>

                              <AlertDialog>
                                <AlertDialogTrigger asChild>
                                  <Button 
                                    variant="ghost" 
                                    size="icon" 
                                    className="h-8 w-8 text-red-500 hover:text-red-600 hover:bg-red-50"
                                  >
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </AlertDialogTrigger>
                                <AlertDialogContent>
                                  <AlertDialogHeader>
                                    <AlertDialogTitle>Remove Member</AlertDialogTitle>
                                    <AlertDialogDescription>
                                      Are you sure you want to remove {member.name} from the Sangam community? 
                                      This action cannot be undone.
                                    </AlertDialogDescription>
                                  </AlertDialogHeader>
                                  <AlertDialogFooter>
                                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                                    <AlertDialogAction 
                                      className="bg-red-600 hover:bg-red-700"
                                      onClick={() => confirmDelete(member.id)}
                                    >
                                      Remove
                                    </AlertDialogAction>
                                  </AlertDialogFooter>
                                </AlertDialogContent>
                              </AlertDialog>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                      {paginatedMembers.length === 0 && (
                        <TableRow>
                          <TableCell colSpan={6} className="text-center py-6 text-muted-foreground">
                            No members found matching your search criteria
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
              <CardFooter className="flex items-center justify-between pt-3">
                <p className="text-sm text-muted-foreground">
                  Showing <strong>{paginatedMembers.length}</strong> of <strong>{filteredMembers.length}</strong> members
                </p>
                <div className="flex items-center space-x-2">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={prevPage}
                    disabled={currentPage === 1}
                  >
                    <ChevronLeft className="h-4 w-4 mr-1" />
                    Previous
                  </Button>
                  <span className="text-sm text-muted-foreground">
                    Page {currentPage} of {totalPages || 1}
                  </span>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={nextPage}
                    disabled={currentPage >= totalPages}
                  >
                    Next
                    <ChevronRight className="h-4 w-4 ml-1" />
                  </Button>
                </div>
              </CardFooter>
            </Card>

            {/* Member Details Dialog */}
            <Dialog open={isViewDetailsOpen} onOpenChange={setIsViewDetailsOpen}>
              <DialogContent className="sm:max-w-[800px] max-h-[90vh] overflow-y-auto">
                {viewMember && (
                  <>
                    <DialogHeader>
                      <DialogTitle>Member Details</DialogTitle>
                      <DialogDescription>
                        Complete information and history for this member
                      </DialogDescription>
                    </DialogHeader>
                    
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 py-4">
                      <Card className="md:col-span-1">
                        <CardHeader>
                          <CardTitle className="text-lg">Personal Information</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                          <div className="mb-8 flex justify-center">
                            <div className="relative">
                              <div className="h-24 w-24 rounded-full bg-sangam-100 flex items-center justify-center">
                                <span className="text-2xl font-bold text-sangam-600">
                                  {viewMember.name.charAt(0)}
                                </span>
                              </div>
                              <Badge className={`absolute bottom-0 right-0 ${
                                viewMember.role === 'Chairman' ? 'bg-sangam-600' : 
                                viewMember.role === 'Treasurer' ? 'bg-amber-500' : 
                                'bg-blue-500'
                              }`}>
                                {viewMember.role}
                              </Badge>
                            </div>
                          </div>

                          <div className="space-y-3">
                            <div className="flex items-start">
                              <div className="w-8 h-8 rounded-full bg-sangam-50 flex items-center justify-center mr-3">
                                <Phone className="h-4 w-4 text-sangam-600" />
                              </div>
                              <div>
                                <p className="text-sm text-muted-foreground">Mobile</p>
                                <p className="font-medium">{viewMember.mobile}</p>
                              </div>
                            </div>
                            
                            <div className="flex items-start">
                              <div className="w-8 h-8 rounded-full bg-sangam-50 flex items-center justify-center mr-3">
                                <Briefcase className="h-4 w-4 text-sangam-600" />
                              </div>
                              <div>
                                <p className="text-sm text-muted-foreground">Occupation</p>
                                <p className="font-medium">{viewMember.occupation}</p>
                              </div>
                            </div>
                            
                            <div className="flex items-start">
                              <div className="w-8 h-8 rounded-full bg-sangam-50 flex items-center justify-center mr-3">
                                <MapPin className="h-4 w-4 text-sangam-600" />
                              </div>
                              <div>
                                <p className="text-sm text-muted-foreground">Address</p>
                                <p className="font-medium">{viewMember.address}</p>
                              </div>
                            </div>
                            
                            <div className="flex items-start">
                              <div className="w-8 h-8 rounded-full bg-sangam-50 flex items-center justify-center mr-3">
                                <Calendar className="h-4 w-4 text-sangam-600" />
                              </div>
                              <div>
                                <p className="text-sm text-muted-foreground">Date of Birth</p>
                                <p className="font-medium">{new Date(viewMember.dob).toLocaleDateString()}</p>
                              </div>
                            </div>
                            
                            <div className="flex items-start">
                              <div className="w-8 h-8 rounded-full bg-sangam-50 flex items-center justify-center mr-3">
                                <Calendar className="h-4 w-4 text-sangam-600" />
                              </div>
                              <div>
                                <p className="text-sm text-muted-foreground">Join Date</p>
                                <p className="font-medium">{new Date(viewMember.joinDate).toLocaleDateString()}</p>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>

                      <div className="md:col-span-2">
                        <Tabs defaultValue="loans" className="w-full">
                          <TabsList className="grid w-full grid-cols-3 mb-2">
                            <TabsTrigger value="loans">Loans</TabsTrigger>
                            <TabsTrigger value="payments">Payments</TabsTrigger>
                            <TabsTrigger value="summary">Summary</TabsTrigger>
                          </TabsList>
                          
                          <TabsContent value="loans" className="mt-0">
                            <Card>
                              <CardHeader className="pb-3">
                                <div className="flex justify-between items-center">
                                  <CardTitle className="text-lg">Loan History</CardTitle>
                                  <Button 
                                    size="sm" 
                                    className="bg-sangam-600 hover:bg-sangam-700"
                                    onClick={() => toast.success("New loan feature coming soon!")}
                                  >
                                    <Plus className="h-3 w-3 mr-1" /> New Loan
                                  </Button>
                                </div>
                              </CardHeader>
                              <CardContent>
                                {getMemberLoans(viewMember.id).length > 0 ? (
                                  <Table>
                                    <TableHeader>
                                      <TableRow>
                                        <TableHead>Amount</TableHead>
                                        <TableHead>Purpose</TableHead>
                                        <TableHead>Issue Date</TableHead>
                                        <TableHead>Balance</TableHead>
                                        <TableHead>Status</TableHead>
                                        <TableHead>Actions</TableHead>
                                      </TableRow>
                                    </TableHeader>
                                    <TableBody>
                                      {getMemberLoans(viewMember.id).map((loan) => (
                                        <TableRow key={loan.id}>
                                          <TableCell className="font-medium">{loan.amount}</TableCell>
                                          <TableCell>{loan.purpose}</TableCell>
                                          <TableCell>{new Date(loan.issueDate).toLocaleDateString()}</TableCell>
                                          <TableCell>{loan.balance}</TableCell>
                                          <TableCell>
                                            <Badge className={loan.status === 'completed' ? 'bg-green-500' : 'bg-amber-500'}>
                                              {loan.status === 'completed' ? 'Completed' : 'Active'}
                                            </Badge>
                                          </TableCell>
                                          <TableCell>
                                            <Button 
                                              variant="ghost" 
                                              size="sm"
                                              onClick={() => handleAddPayment(viewMember.id)}
                                            >
                                              <CreditCard className="h-4 w-4 mr-1" /> Pay
                                            </Button>
                                          </TableCell>
                                        </TableRow>
                                      ))}
                                    </TableBody>
                                  </Table>
                                ) : (
                                  <div className="text-center py-8">
                                    <CreditCard className="mx-auto h-12 w-12 text-muted-foreground opacity-30 mb-3" />
                                    <h3 className="text-lg font-medium mb-1">No Loans</h3>
                                    <p className="text-sm text-muted-foreground">
                                      This member has no active or past loans.
                                    </p>
                                  </div>
                                )}
                              </CardContent>
                            </Card>
                          </TabsContent>
                          
                          <TabsContent value="payments" className="mt-0">
                            <Card>
                              <CardHeader className="pb-3">
                                <div className="flex justify-between items-center">
                                  <CardTitle className="text-lg">Payment History</CardTitle>
                                  <Button 
                                    size="sm" 
                                    variant="outline"
                                    onClick={() => toast.success("Payment export feature coming soon!")}
                                  >
                                    <Download className="h-4 w-4 mr-1" /> Export
                                  </Button>
                                </div>
                              </CardHeader>
                              <CardContent>
                                {getMemberPayments(viewMember.id).length > 0 ? (
                                  <Table>
                                    <TableHeader>
                                      <TableRow>
                                        <TableHead>Date</TableHead>
                                        <TableHead>Amount</TableHead>
                                        <TableHead>Type</TableHead>
                                        <TableHead>Method</TableHead>
                                        <TableHead>Actions</TableHead>
                                      </TableRow>
                                    </TableHeader>
                                    <TableBody>
                                      {getMemberPayments(viewMember.id).map((payment) => (
                                        <TableRow key={payment.id}>
                                          <TableCell>{new Date(payment.date).toLocaleDateString()}</TableCell>
                                          <TableCell className="font-medium">{payment.amount}</TableCell>
                                          <TableCell>
                                            <Badge className={payment.type === 'loan' ? 'bg-sangam-500' : 'bg-blue-500'}>
                                              {payment.type === 'loan' ? 'Loan Payment' : 'Monthly Dues'}
                                            </Badge>
                                          </TableCell>
                                          <TableCell>{payment.method.toUpperCase()}</TableCell>
                                          <TableCell>
                                            <Button 
                                              variant="ghost" 
                                              size="sm"
                                              onClick={() => toast.success(`Receipt for payment ${payment.id} generated`)}
                                            >
                                              <Download className="h-4 w-4 mr-1" /> Receipt
                                            </Button>
                                          </TableCell>
                                        </TableRow>
                                      ))}
                                    </TableBody>
                                  </Table>
                                ) : (
                                  <div className="text-center py-8">
                                    <CreditCard className="mx-auto h-12 w-12 text-muted-foreground opacity-30 mb-3" />
                                    <h3 className="text-lg font-medium mb-1">No Payments</h3>
                                    <p className="text-sm text-muted-foreground">
                                      This member has no payment records.
                                    </p>
                                  </div>
                                )}
                              </CardContent>
                            </Card>
                          </TabsContent>
                          
                          <TabsContent value="summary" className="mt-0">
                            <Card>
                              <CardHeader className="pb-3">
                                <CardTitle className="text-lg">Financial Summary</CardTitle>
                              </CardHeader>
                              <CardContent>
                                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                  <div className="p-4 rounded-lg border bg-muted/20">
                                    <p className="text-sm text-muted-foreground">Total Loans</p>
                                    <p className="text-xl font-bold">
                                      {getMemberLoans(viewMember.id).length > 0 
                                        ? `₹${getMemberLoans(viewMember.id).reduce((sum, loan) => 
                                            sum + parseInt(loan.amount.replace('₹', '').replace(',', '')), 0
                                          ).toLocaleString()}`
                                        : '₹0'}
                                    </p>
                                  </div>
                                  
                                  <div className="p-4 rounded-lg border bg-muted/20">
                                    <p className="text-sm text-muted-foreground">Outstanding Balance</p>
                                    <p className="text-xl font-bold">
                                      {getMemberLoans(viewMember.id).length > 0 
                                        ? `₹${getMemberLoans(viewMember.id).reduce((sum, loan) => 
                                            sum + parseInt(loan.balance.replace('₹', '').replace(',', '')), 0
                                          ).toLocaleString()}`
                                        : '₹0'}
                                    </p>
                                  </div>
                                  
                                  <div className="p-4 rounded-lg border bg-muted/20">
                                    <p className="text-sm text-muted-foreground">Total Payments</p>
                                    <p className="text-xl font-bold">
                                      {getMemberPayments(viewMember.id).length > 0 
                                        ? `₹${getMemberPayments(viewMember.id).reduce((sum, payment) => 
                                            sum + parseInt(payment.amount.replace('₹', '').replace(',', '')), 0
                                          ).toLocaleString()}`
                                        : '₹0'}
                                    </p>
                                  </div>
                                  
                                  <div className="p-4 rounded-lg border bg-muted/20">
                                    <p className="text-sm text-muted-foreground">Monthly Dues Status</p>
                                    <p className="text-xl font-bold text-green-600">Paid</p>
                                  </div>
                                </div>
                                <div className="mt-6">
                                  <Button
                                    className="w-full"
                                    onClick={() => toast.success("Detailed report feature coming soon!")}
                                  >
                                    Generate Detailed Report
                                  </Button>
                                </div>
                              </CardContent>
                            </Card>
                          </TabsContent>
                        </Tabs>
                      </div>
                    </div>
                    
                    <DialogFooter className="gap-2">
                      <Button 
                        variant="outline" 
                        onClick={() => {
                          handleEditMember(viewMember.id);
                          setIsViewDetailsOpen(false);
                        }}
                      >
                        <Edit className="h-4 w-4 mr-2" />
                        Edit Member
                      </Button>

                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="destructive">
                            <Trash2 className="h-4 w-4 mr-2" />
                            Remove Member
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Remove Member</AlertDialogTitle>
                            <AlertDialogDescription>
                              Are you sure you want to remove {viewMember.name} from the Sangam community? 
                              This action cannot be undone.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction 
                              className="bg-red-600 hover:bg-red-700"
                              onClick={() => {
                                confirmDelete(viewMember.id);
                                setIsViewDetailsOpen(false);
                              }}
                            >
                              Remove
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </DialogFooter>
                  </>
                )}
              </DialogContent>
            </Dialog>

            {/* Edit Member Dialog */}
            <Dialog open={isEditMemberOpen} onOpenChange={setIsEditMemberOpen}>
              <DialogContent className="sm:max-w-[525px]">
                {editingMember && (
                  <>
                    <DialogHeader>
                      <DialogTitle>Edit Member</DialogTitle>
                      <DialogDescription>
                        Update member information
                      </DialogDescription>
                    </DialogHeader>
                    <div className="grid gap-4 py-4">
                      <div className="grid grid-cols-4 items-center gap-4">
                        <Label htmlFor="edit-name" className="text-right">
                          Full Name
                        </Label>
                        <Input
                          id="edit-name"
                          value={editingMember.name}
                          onChange={(e) => setEditingMember({...editingMember, name: e.target.value})}
                          className="col-span-3"
                        />
                      </div>
                      <div className="grid grid-cols-4 items-center gap-4">
                        <Label htmlFor="edit-mobile" className="text-right">
                          Mobile
                        </Label>
                        <Input
                          id="edit-mobile"
                          value={editingMember.mobile}
                          onChange={(e) => setEditingMember({...editingMember, mobile: e.target.value})}
                          className="col-span-3"
                        />
                      </div>
                      <div className="grid grid-cols-4 items-center gap-4">
                        <Label htmlFor="edit-occupation" className="text-right">
                          Occupation
                        </Label>
                        <Input
                          id="edit-occupation"
                          value={editingMember.occupation}
                          onChange={(e) => setEditingMember({...editingMember, occupation: e.target.value})}
                          className="col-span-3"
                        />
                      </div>
                      <div className="grid grid-cols-4 items-center gap-4">
                        <Label htmlFor="edit-address" className="text-right">
                          Address
                        </Label>
                        <Input
                          id="edit-address"
                          value={editingMember.address}
                          onChange={(e) => setEditingMember({...editingMember, address: e.target.value})}
                          className="col-span-3"
                        />
                      </div>
                      <div className="grid grid-cols-4 items-center gap-4">
                        <Label htmlFor="edit-dob" className="text-right">
                          Date of Birth
                        </Label>
                        <Input
                          id="edit-dob"
                          type="date"
                          value={editingMember.dob}
                          onChange={(e) => setEditingMember({...editingMember, dob: e.target.value})}
                          className="col-span-3"
                        />
                      </div>
                      <div className="grid grid-cols-4 items-center gap-4">
                        <Label htmlFor="edit-role" className="text-right">
                          Role
                        </Label>
                        <select
                          id="edit-role"
                          value={editingMember.role}
                          onChange={(e) => setEditingMember({...editingMember, role: e.target.value as Member['role']})}
                          className="col-span-3 flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                        >
                          <option value="Member">Member</option>
                          <option value="Treasurer">Treasurer</option>
                          <option value="Chairman">Chairman</option>
                        </select>
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setIsEditMemberOpen(false)}>Cancel</Button>
                      <Button onClick={handleUpdateMember} className="bg-sangam-600 hover:bg-sangam-700">Update Member</Button>
                    </DialogFooter>
                  </>
                )}
              </DialogContent>
            </Dialog>

            {/* Delete Member Dialog */}
            <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Confirm Removal</AlertDialogTitle>
                  <AlertDialogDescription>
                    Are you sure you want to remove this member? This action cannot be undone.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel onClick={() => setMemberToDelete(null)}>Cancel</AlertDialogCancel>
                  <AlertDialogAction 
                    className="bg-red-600 hover:bg-red-700"
                    onClick={handleDeleteMember}
                  >
                    Remove
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </div>
      </div>
    </SidebarProvider>
  );
}

