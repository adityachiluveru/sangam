
import { SidebarProvider } from '@/components/ui/sidebar';
import { AppSidebar } from '@/components/AppSidebar';
import React, { useState } from 'react';
import { 
  Table, 
  TableHeader, 
  TableRow, 
  TableHead, 
  TableBody, 
  TableCell 
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { 
  CalendarIcon, 
  FilterX, 
  Download, 
  ArrowDownUp, 
  Eye,
  Check,
  Clock,
  AlertCircle,
  ChevronDown
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { StatCard } from "@/components/StatCard";
import { format } from "date-fns";

const currentMonth = new Date().toLocaleString('default', { month: 'long' });
const currentYear = new Date().getFullYear();

// Enhanced transaction data with status and category
const dummyTransactions = [
  {
    id: 1,
    memberName: 'Rahul Sharma',
    amount: 2500,
    type: 'Payment',
    date: '2025-05-01',
    method: 'UPI',
    reference: 'SANGAM25787',
    status: 'Completed',
    category: 'Loan Repayment'
  },
  {
    id: 2,
    memberName: 'Priya Singh',
    amount: 25000,
    type: 'Loan',
    date: '2025-04-25',
    method: 'Bank Transfer',
    reference: 'SANGAM25786',
    status: 'Completed',
    category: 'New Loan'
  },
  {
    id: 3,
    memberName: 'Amit Patel',
    amount: 5000,
    type: 'Payment',
    date: '2025-05-05',
    method: 'Cash',
    reference: 'SANGAM25785',
    status: 'Pending',
    category: 'Loan Repayment'
  },
  {
    id: 4,
    memberName: 'Meera Desai',
    amount: 3750,
    type: 'Payment',
    date: '2025-04-15',
    method: 'UPI',
    reference: 'SANGAM25784',
    status: 'Completed',
    category: 'Loan Repayment'
  },
  {
    id: 5,
    memberName: 'Sanjay Kumar',
    amount: 75000,
    type: 'Loan',
    date: '2025-04-10',
    method: 'Bank Transfer',
    reference: 'SANGAM25783',
    status: 'Completed',
    category: 'New Loan'
  },
  {
    id: 6,
    memberName: 'Vijay Reddy',
    amount: 8000,
    type: 'Payment',
    date: '2025-05-08',
    method: 'UPI',
    reference: 'SANGAM25782',
    status: 'Failed',
    category: 'Loan Repayment'
  },
  {
    id: 7,
    memberName: 'Ananya Joshi',
    amount: 6200,
    type: 'Payment',
    date: '2025-05-03',
    method: 'Bank Transfer',
    reference: 'SANGAM25781',
    status: 'Completed',
    category: 'Loan Repayment'
  },
  {
    id: 8,
    memberName: 'Rohit Verma',
    amount: 50000,
    type: 'Loan',
    date: '2025-05-07',
    method: 'Bank Transfer',
    reference: 'SANGAM25780',
    status: 'Processing',
    category: 'New Loan'
  }
];

const Transactions = () => {
  const [transactions] = useState(dummyTransactions);
  const [activeTab, setActiveTab] = useState("all");

  // Filter transactions for various metrics
  const currentMonthTransactions = transactions.filter(t => {
    const transDate = new Date(t.date);
    const currentDate = new Date();
    return transDate.getMonth() === currentDate.getMonth() && 
           transDate.getFullYear() === currentDate.getFullYear();
  });

  // Payments received this month
  const monthlyPaymentsReceived = currentMonthTransactions
    .filter(t => t.type === 'Payment' && t.status === 'Completed')
    .reduce((sum, t) => sum + t.amount, 0);

  // Loans disbursed this month
  const monthlyLoansIssued = currentMonthTransactions
    .filter(t => t.type === 'Loan' && (t.status === 'Completed' || t.status === 'Processing'))
    .reduce((sum, t) => sum + t.amount, 0);

  // Pending payments
  const pendingPayments = transactions
    .filter(t => t.type === 'Payment' && t.status === 'Pending')
    .reduce((sum, t) => sum + t.amount, 0);

  // Failed payments
  const failedPayments = transactions
    .filter(t => t.type === 'Payment' && t.status === 'Failed')
    .reduce((sum, t) => sum + t.amount, 0);

  // Total payments and loans of all time
  const totalPayments = transactions
    .filter(t => t.type === 'Payment' && t.status === 'Completed')
    .reduce((sum, t) => sum + t.amount, 0);

  const totalLoans = transactions
    .filter(t => t.type === 'Loan' && (t.status === 'Completed' || t.status === 'Processing'))
    .reduce((sum, t) => sum + t.amount, 0);

  // Filter transactions based on active tab
  const getFilteredTransactions = () => {
    switch(activeTab) {
      case "payments":
        return transactions.filter(t => t.type === 'Payment');
      case "loans":
        return transactions.filter(t => t.type === 'Loan');
      case "pending":
        return transactions.filter(t => t.status === 'Pending');
      case "completed":
        return transactions.filter(t => t.status === 'Completed');
      default:
        return transactions;
    }
  };

  const filteredTransactions = getFilteredTransactions();

  const getStatusBadge = (status: string) => {
    switch(status.toLowerCase()) {
      case 'completed':
        return <Badge variant="outline" className="bg-green-100 text-green-800 flex items-center gap-1">
          <Check size={12} />
          <span>Completed</span>
        </Badge>;
      case 'pending':
        return <Badge variant="outline" className="bg-yellow-100 text-yellow-800 flex items-center gap-1">
          <Clock size={12} />
          <span>Pending</span>
        </Badge>;
      case 'failed':
        return <Badge variant="outline" className="bg-red-100 text-red-800 flex items-center gap-1">
          <AlertCircle size={12} />
          <span>Failed</span>
        </Badge>;
      case 'processing':
        return <Badge variant="outline" className="bg-blue-100 text-blue-800 flex items-center gap-1">
          <Clock size={12} />
          <span>Processing</span>
        </Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full">
        <AppSidebar />
        <div className="flex-1 pl-16 md:pl-64">
          <div className="p-6 max-w-7xl mx-auto animate-fade-in">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
              <div>
                <h1 className="text-2xl font-bold">Transactions</h1>
                <p className="text-muted-foreground">Track all financial activities</p>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" className="flex items-center gap-2">
                  <CalendarIcon size={16} />
                  <span>Date Range</span>
                </Button>
                <Button className="flex items-center gap-2">
                  <Download size={16} />
                  <span>Export</span>
                </Button>
              </div>
            </div>
            
            {/* Enhanced dashboard cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <StatCard
                title={`Payments Received (${currentMonth})`}
                value={`₹${monthlyPaymentsReceived.toLocaleString()}`}
                description="This month's total"
                className="bg-gradient-to-br from-green-50 to-emerald-50 border-green-100"
              />
              
              <StatCard
                title={`Loans Disbursed (${currentMonth})`}
                value={`₹${monthlyLoansIssued.toLocaleString()}`}
                description="This month's total"
                className="bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-100"
              />
              
              <StatCard
                title="Pending Payments"
                value={`₹${pendingPayments.toLocaleString()}`}
                description="Awaiting settlement"
                className="bg-gradient-to-br from-amber-50 to-yellow-50 border-amber-100"
              />
              
              <StatCard
                title="Failed Transactions"
                value={`₹${failedPayments.toLocaleString()}`}
                description="Requires attention"
                className="bg-gradient-to-br from-red-50 to-rose-50 border-red-100"
              />
            </div>
            
            {/* Account summary cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              <Card className="bg-gradient-to-br from-sangam-50 to-white">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Collection Summary</CardTitle>
                  <CardDescription>Total payments received to date</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-green-600">₹{totalPayments.toLocaleString()}</div>
                  <div className="mt-4 grid grid-cols-2 gap-4">
                    <div className="bg-white p-3 rounded-lg border">
                      <div className="text-sm text-muted-foreground">This Month</div>
                      <div className="text-xl font-semibold mt-1">₹{monthlyPaymentsReceived.toLocaleString()}</div>
                    </div>
                    <div className="bg-white p-3 rounded-lg border">
                      <div className="text-sm text-muted-foreground">Pending</div>
                      <div className="text-xl font-semibold mt-1">₹{pendingPayments.toLocaleString()}</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-gradient-to-br from-indigo-50 to-white">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Loan Summary</CardTitle>
                  <CardDescription>Total loans disbursed to date</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-blue-600">₹{totalLoans.toLocaleString()}</div>
                  <div className="mt-4 grid grid-cols-2 gap-4">
                    <div className="bg-white p-3 rounded-lg border">
                      <div className="text-sm text-muted-foreground">This Month</div>
                      <div className="text-xl font-semibold mt-1">₹{monthlyLoansIssued.toLocaleString()}</div>
                    </div>
                    <div className="bg-white p-3 rounded-lg border">
                      <div className="text-sm text-muted-foreground">Active Loans</div>
                      <div className="text-xl font-semibold mt-1">{transactions.filter(t => t.type === 'Loan').length}</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            {/* Transactions table with tabs */}
            <div className="bg-white rounded-lg shadow-sm border">
              <div className="p-4 border-b">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                  <h2 className="text-lg font-medium">Transaction History</h2>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" className="flex items-center gap-1">
                      <FilterX size={14} />
                      <span>Filters</span>
                    </Button>
                    <Button variant="outline" size="sm" className="flex items-center gap-1">
                      <ArrowDownUp size={14} />
                      <span>Sort</span>
                      <ChevronDown size={14} />
                    </Button>
                  </div>
                </div>

                <Tabs 
                  value={activeTab} 
                  onValueChange={setActiveTab} 
                  className="mt-4"
                >
                  <TabsList className="grid grid-cols-2 sm:grid-cols-5 gap-2 bg-muted/50">
                    <TabsTrigger value="all">All</TabsTrigger>
                    <TabsTrigger value="payments">Payments</TabsTrigger>
                    <TabsTrigger value="loans">Loans</TabsTrigger>
                    <TabsTrigger value="pending">Pending</TabsTrigger>
                    <TabsTrigger value="completed">Completed</TabsTrigger>
                  </TabsList>
                </Tabs>
              </div>
              
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Member Name</TableHead>
                      <TableHead>Amount (₹)</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Payment Method</TableHead>
                      <TableHead>Reference</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredTransactions.map((transaction) => (
                      <TableRow key={transaction.id}>
                        <TableCell className="font-medium">{transaction.memberName}</TableCell>
                        <TableCell>₹{transaction.amount.toLocaleString()}</TableCell>
                        <TableCell>
                          <Badge variant="outline" className={transaction.type === 'Payment' ? 
                            'bg-green-100 text-green-800' : 
                            'bg-blue-100 text-blue-800'}>
                            {transaction.type}
                          </Badge>
                        </TableCell>
                        <TableCell>{transaction.category}</TableCell>
                        <TableCell>{format(new Date(transaction.date), "dd MMM yyyy")}</TableCell>
                        <TableCell>{getStatusBadge(transaction.status)}</TableCell>
                        <TableCell>{transaction.method}</TableCell>
                        <TableCell>{transaction.reference}</TableCell>
                        <TableCell>
                          <Button variant="ghost" size="icon" title="View Details">
                            <Eye size={16} />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                    {filteredTransactions.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={9} className="text-center py-6 text-muted-foreground">
                          No transactions found for the selected filter
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
              
              <div className="p-4 border-t flex flex-col sm:flex-row sm:items-center sm:justify-between text-sm text-muted-foreground">
                <div>
                  Showing {filteredTransactions.length} transactions
                </div>
                <div className="mt-2 sm:mt-0">
                  Updated on {format(new Date(), "dd MMMM yyyy")}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </SidebarProvider>
  );
};

export default Transactions;
