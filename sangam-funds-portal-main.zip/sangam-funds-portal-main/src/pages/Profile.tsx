
import { useState } from 'react';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAuth } from '@/context/AuthContext';
import { useLanguage } from '@/context/LanguageContext';
import { useToast } from '@/hooks/use-toast';
import { User, Mail, Phone, Globe, Shield } from 'lucide-react';

const ProfilePage = () => {
  const { user } = useAuth();
  const { language, setLanguage, t } = useLanguage();
  const { toast } = useToast();
  
  const [profile, setProfile] = useState({
    username: user?.username || 'Admin User',
    email: 'admin@sangam.com',
    phone: '+91 98765 43210',
    role: user?.role || 'admin'
  });

  const [isEditing, setIsEditing] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setProfile({
      ...profile,
      [name]: value
    });
  };

  const handleLanguageChange = (value: string) => {
    setLanguage(value as 'english' | 'telugu');
  };

  const handleSaveProfile = () => {
    // In a real application, this would call an API to update the profile
    setIsEditing(false);
    toast({
      title: language === 'english' ? 'Profile Updated' : 'ప్రొఫైల్ నవీకరించబడింది',
      description: language === 'english' 
        ? 'Your profile has been updated successfully' 
        : 'మీ ప్రొఫైల్ విజయవంతంగా నవీకరించబడింది',
    });
  };

  return (
    <div className="p-6 space-y-6 animate-fade-in">
      <h1 className="text-3xl font-bold text-sangam-800">
        {language === 'english' ? 'My Profile' : 'నా ప్రొఫైల్'}
      </h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="col-span-1">
          <Card className="sangam-card hover-scale">
            <CardHeader className="text-center">
              <div className="flex justify-center mb-4">
                <Avatar className="h-24 w-24 border-2 border-sangam-200 shadow-md">
                  <AvatarFallback className="bg-sangam-100 text-sangam-600 text-2xl">
                    {profile.username ? profile.username[0].toUpperCase() : 'A'}
                  </AvatarFallback>
                </Avatar>
              </div>
              <CardTitle className="text-xl">{profile.username}</CardTitle>
              <CardDescription className="flex items-center justify-center gap-2">
                <Shield className="h-4 w-4 text-sangam-500" />
                <span className="capitalize">{profile.role}</span>
              </CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              <div className="space-y-2 text-sm text-muted-foreground">
                <div className="flex items-center justify-center gap-2">
                  <Mail className="h-4 w-4" />
                  <span>{profile.email}</span>
                </div>
                <div className="flex items-center justify-center gap-2">
                  <Phone className="h-4 w-4" />
                  <span>{profile.phone}</span>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button 
                className="w-full button-hover"
                variant={isEditing ? "outline" : "default"}
                onClick={() => setIsEditing(!isEditing)}
              >
                {isEditing 
                  ? (language === 'english' ? 'Cancel Editing' : 'సవరణను రద్దు చేయండి')
                  : (language === 'english' ? 'Edit Profile' : 'ప్రొఫైల్‌ని సవరించండి')}
              </Button>
            </CardFooter>
          </Card>
        </div>

        <div className="col-span-1 md:col-span-2">
          <Card className="sangam-card h-full">
            <CardHeader>
              <CardTitle>
                {language === 'english' ? 'Account Settings' : 'ఖాతా సెట్టింగ్‌లు'}
              </CardTitle>
              <CardDescription>
                {language === 'english' 
                  ? 'Manage your account settings and preferences' 
                  : 'మీ ఖాతా సెట్టింగ్‌లు మరియు ప్రాధాన్యతలను నిర్వహించండి'}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="profile" className="w-full">
                <TabsList className="grid w-full grid-cols-2 mb-6">
                  <TabsTrigger value="profile" className="transition-all">
                    <User className="h-4 w-4 mr-2" />
                    {language === 'english' ? 'Profile' : 'ప్రొఫైల్'}
                  </TabsTrigger>
                  <TabsTrigger value="preferences" className="transition-all">
                    <Globe className="h-4 w-4 mr-2" />
                    {language === 'english' ? 'Preferences' : 'ప్రాధాన్యతలు'}
                  </TabsTrigger>
                </TabsList>
                <TabsContent value="profile" className="space-y-4 animate-fade-in">
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="username">
                          {language === 'english' ? 'Username' : 'వినియోగదారు పేరు'}
                        </Label>
                        <Input
                          id="username"
                          name="username"
                          value={profile.username}
                          onChange={handleInputChange}
                          disabled={!isEditing}
                          className="transition-all focus:ring-sangam-500"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="email">
                          {language === 'english' ? 'Email' : 'ఇమెయిల్'}
                        </Label>
                        <Input
                          id="email"
                          name="email"
                          type="email"
                          value={profile.email}
                          onChange={handleInputChange}
                          disabled={!isEditing}
                          className="transition-all focus:ring-sangam-500"
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="phone">
                          {language === 'english' ? 'Phone' : 'ఫోన్'}
                        </Label>
                        <Input
                          id="phone"
                          name="phone"
                          value={profile.phone}
                          onChange={handleInputChange}
                          disabled={!isEditing}
                          className="transition-all focus:ring-sangam-500"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="role">
                          {language === 'english' ? 'Role' : 'పాత్ర'}
                        </Label>
                        <Input
                          id="role"
                          name="role"
                          value={profile.role}
                          disabled={true}
                          className="bg-muted"
                        />
                      </div>
                    </div>
                    {isEditing && (
                      <div className="flex justify-end">
                        <Button 
                          onClick={handleSaveProfile}
                          className="transition-colors button-hover"
                        >
                          {language === 'english' ? 'Save Changes' : 'మార్పులను సేవ్ చేయండి'}
                        </Button>
                      </div>
                    )}
                  </div>
                </TabsContent>
                <TabsContent value="preferences" className="space-y-4 animate-fade-in">
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="language">
                          {language === 'english' ? 'Language' : 'భాష'}
                        </Label>
                        <Select
                          value={language}
                          onValueChange={handleLanguageChange}
                        >
                          <SelectTrigger className="w-full transition-all focus:ring-sangam-500">
                            <SelectValue placeholder={language === 'english' ? 'Select language' : 'భాషను ఎంచుకోండి'} />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="english">English</SelectItem>
                            <SelectItem value="telugu">తెలుగు</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;
