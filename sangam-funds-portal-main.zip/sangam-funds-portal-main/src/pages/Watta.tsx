
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle
} from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Search, ArrowUpDown, Eye, Plus, CreditCard, Wallet, ArrowRight } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { useLanguage } from '@/context/LanguageContext';
import { cn } from '@/lib/utils';
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

// Mock data for member balances
const initialMembers = [
  { id: 1, name: 'Rajesh Kumar', balance: 12500, status: 'positive', transactions: [] },
  { id: 2, name: 'Sunil Reddy', balance: -3000, status: 'negative', transactions: [] },
  { id: 3, name: 'Venkat Rao', balance: 7800, status: 'positive', transactions: [] },
  { id: 4, name: 'Priya Sharma', balance: 0, status: 'neutral', transactions: [] },
  { id: 5, name: 'Anil Kumar', balance: 5200, status: 'positive', transactions: [] },
  { id: 6, name: 'Kavitha Devi', balance: -1500, status: 'negative', transactions: [] },
  { id: 7, name: 'Ramesh Babu', balance: 9300, status: 'positive', transactions: [] },
  { id: 8, name: 'Lakshmi Prasad', balance: 3600, status: 'positive', transactions: [] },
];

// Add mock transactions for each member
initialMembers.forEach(member => {
  // Generate between 3-6 random transactions for each member
  const transactionCount = Math.floor(Math.random() * 4) + 3;
  
  for (let i = 0; i < transactionCount; i++) {
    const amount = Math.floor(Math.random() * 5000) - 2000;
    const date = new Date();
    date.setDate(date.getDate() - Math.floor(Math.random() * 30)); // Random date in the last 30 days
    
    member.transactions.push({
      id: `${member.id}-${i}`,
      amount,
      type: amount > 0 ? 'credit' : 'debit',
      date: date.toISOString(),
      description: amount > 0 ? 'Committee Deposit' : 'Loan Withdrawal'
    });
  }
});

// Mock interest rates for committee
const committeeInterest = {
  deposit: 12, // 12% annual interest for deposits
  loan: 24 // 24% annual interest for loans
};

// Status classes for balance styling
const statusClasses = {
  positive: 'text-green-600',
  negative: 'text-red-600',
  neutral: 'text-gray-600',
};

const WattaPage = () => {
  const [members, setMembers] = useState(initialMembers);
  const [searchTerm, setSearchTerm] = useState('');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');
  const [selectedMember, setSelectedMember] = useState<any>(null);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [isTransactionDialogOpen, setIsTransactionDialogOpen] = useState(false);
  const [newTransactionAmount, setNewTransactionAmount] = useState('');
  const [newTransactionType, setNewTransactionType] = useState('credit');
  const [newTransactionDescription, setNewTransactionDescription] = useState('');
  const { toast } = useToast();
  const { t, language } = useLanguage();

  // Filter members based on search term
  const filteredMembers = members.filter((member) =>
    member.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Sort members based on balance
  const sortedMembers = [...filteredMembers].sort((a, b) => {
    return sortOrder === 'asc' ? a.balance - b.balance : b.balance - a.balance;
  });

  // Toggle sort order
  const toggleSortOrder = () => {
    setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
  };

  // View member details
  const handleViewMember = (id: number) => {
    const member = members.find((m) => m.id === id);
    setSelectedMember(member);
    setIsViewDialogOpen(true);
  };

  // Get interest calculation for a member
  const calculateInterest = (balance: number) => {
    if (balance > 0) {
      // Calculate interest for positive balance (deposit)
      return (balance * committeeInterest.deposit) / 100;
    } else if (balance < 0) {
      // Calculate interest for negative balance (loan)
      return (Math.abs(balance) * committeeInterest.loan) / 100;
    }
    return 0;
  };

  // Format date for display
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString(language === 'english' ? 'en-US' : 'te-IN', { 
      day: 'numeric', 
      month: 'short', 
      year: 'numeric' 
    });
  };

  // Add transaction
  const handleAddTransaction = () => {
    if (!selectedMember || !newTransactionAmount || isNaN(Number(newTransactionAmount))) {
      toast({
        title: language === 'english' ? 'Invalid Input' : 'చెల్లని ఇన్‌పుట్',
        description: language === 'english' ? 'Please enter a valid amount' : 'దయచేసి చెల్లుబాటు అయ్యే మొత్తాన్ని నమోదు చేయండి',
        variant: 'destructive',
      });
      return;
    }

    const transactionAmount = newTransactionType === 'credit' 
      ? Math.abs(Number(newTransactionAmount))
      : -Math.abs(Number(newTransactionAmount));
    
    const newTransaction = {
      id: `${selectedMember.id}-${Date.now()}`,
      amount: transactionAmount,
      type: newTransactionType,
      date: new Date().toISOString(),
      description: newTransactionDescription || (transactionAmount > 0 ? 'Committee Deposit' : 'Loan Withdrawal')
    };

    setMembers(members.map(member => {
      if (member.id === selectedMember.id) {
        const newBalance = member.balance + transactionAmount;
        return {
          ...member,
          balance: newBalance,
          status: newBalance > 0 ? 'positive' : newBalance < 0 ? 'negative' : 'neutral',
          transactions: [...member.transactions, newTransaction]
        };
      }
      return member;
    }));
    
    setIsTransactionDialogOpen(false);
    setNewTransactionAmount('');
    setNewTransactionDescription('');

    toast({
      title: language === 'english' ? 'Transaction Added' : 'లావాదేవీ జోడించబడింది',
      description: language === 'english' 
        ? `Amount ${transactionAmount > 0 ? 'credited' : 'debited'}: ₹${Math.abs(transactionAmount)}` 
        : `మొత్తం ${transactionAmount > 0 ? 'జమ చేయబడింది' : 'డెబిట్ చేయబడింది'}: ₹${Math.abs(transactionAmount)}`,
    });
  };

  // Open transaction dialog
  const openTransactionDialog = (id: number) => {
    const member = members.find((m) => m.id === id);
    setSelectedMember(member);
    setIsTransactionDialogOpen(true);
    setNewTransactionType('credit');
  };

  return (
    <div className="p-6 space-y-6 animate-fade-in">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-sangam-800 animate-slide-in">{t('watta')}</h1>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="sangam-card hover-scale transition-all duration-300">
          <CardHeader className="pb-2">
            <CardTitle className="text-sangam-700">{language === 'english' ? 'Total Positive Balance' : 'మొత్తం పాజిటివ్ నిల్వ'}</CardTitle>
            <CardDescription>{language === 'english' ? 'Members with credit' : 'క్రెడిట్‌తో సభ్యులు'}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              ₹{members.filter(m => m.balance > 0).reduce((sum, member) => sum + member.balance, 0).toLocaleString()}
            </div>
          </CardContent>
        </Card>
        
        <Card className="sangam-card hover-scale transition-all duration-300">
          <CardHeader className="pb-2">
            <CardTitle className="text-sangam-700">{language === 'english' ? 'Total Negative Balance' : 'మొత్తం నెగటివ్ నిల్వ'}</CardTitle>
            <CardDescription>{language === 'english' ? 'Members with debit' : 'డెబిట్‌తో సభ్యులు'}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">
              ₹{Math.abs(members.filter(m => m.balance < 0).reduce((sum, member) => sum + member.balance, 0)).toLocaleString()}
            </div>
          </CardContent>
        </Card>
        
        <Card className="sangam-card hover-scale transition-all duration-300">
          <CardHeader className="pb-2">
            <CardTitle className="text-sangam-700">{language === 'english' ? 'Net Balance' : 'నికర నిల్వ'}</CardTitle>
            <CardDescription>{language === 'english' ? 'Overall committee position' : 'మొత్తం కమిటీ స్థానం'}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className={cn(
              "text-2xl font-bold",
              members.reduce((sum, member) => sum + member.balance, 0) > 0 
                ? "text-green-600" 
                : members.reduce((sum, member) => sum + member.balance, 0) < 0 
                  ? "text-red-600" 
                  : "text-gray-600"
            )}>
              ₹{members.reduce((sum, member) => sum + member.balance, 0).toLocaleString()}
            </div>
          </CardContent>
        </Card>
      </div>
      
      <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
        <div className="relative w-full sm:w-64">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder={t('searchMember')}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-8 transition-all focus:ring-2 focus:ring-sangam-500"
          />
        </div>
        <Button
          variant="outline"
          className="border-sangam-200 hover:bg-sangam-50 hover:text-sangam-800 transition-colors button-hover"
          onClick={toggleSortOrder}
        >
          <ArrowUpDown className="mr-2 h-4 w-4" />
          {language === 'english' ? 'Sort by Balance' : 'నిల్వ ద్వారా క్రమబద్ధీకరించండి'}
        </Button>
      </div>
      
      <div className="rounded-md border shadow-sm overflow-hidden transition-shadow hover:shadow-md">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[100px]">{t('name')}</TableHead>
              <TableHead>{t('balance')}</TableHead>
              <TableHead className="w-[100px] text-right">{t('action')}</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {sortedMembers.map((member, index) => (
              <TableRow 
                key={member.id} 
                className="hover-row transition-colors" 
                style={{ animationDelay: `${index * 50}ms` }}
              >
                <TableCell className="font-medium">{member.name}</TableCell>
                <TableCell className={statusClasses[member.status as keyof typeof statusClasses]}>
                  <div className="flex items-center gap-2">
                    ₹{member.balance.toLocaleString()}
                    <Badge 
                      variant={member.status === 'positive' ? 'default' : member.status === 'negative' ? 'destructive' : 'outline'} 
                      className="ml-2 transition-all"
                    >
                      {member.status === 'positive' 
                        ? (language === 'english' ? 'Credit' : 'క్రెడిట్') 
                        : member.status === 'negative' 
                          ? (language === 'english' ? 'Debit' : 'డెబిట్')
                          : (language === 'english' ? 'Neutral' : 'తటస్థం')}
                    </Badge>
                  </div>
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-2">
                    <Button size="sm" variant="ghost" onClick={() => handleViewMember(member.id)} className="transition-colors hover:bg-sangam-100">
                      <Eye className="h-4 w-4 mr-1" />
                      {t('view')}
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => openTransactionDialog(member.id)} className="transition-colors hover:bg-sangam-100">
                      <Plus className="h-4 w-4 mr-1" />
                      {language === 'english' ? 'Trans' : 'లావా'}
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* Member Details Dialog */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-xl text-sangam-800">
              {selectedMember?.name} {language === 'english' ? 'Details' : 'వివరాలు'}
            </DialogTitle>
            <DialogDescription>
              {language === 'english' ? 'Member balance and transaction history' : 'సభ్యుని బ్యాలెన్స్ మరియు లావాదేవీ చరిత్ర'}
            </DialogDescription>
          </DialogHeader>

          {selectedMember && (
            <div className="space-y-6">
              {/* Summary Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card>
                  <CardHeader className="py-2">
                    <CardTitle className="text-base">{language === 'english' ? 'Current Balance' : 'ప్రస్తుత బ్యాలెన్స్'}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className={cn(
                      "text-xl font-bold",
                      selectedMember.status === 'positive' 
                        ? "text-green-600" 
                        : selectedMember.status === 'negative' 
                          ? "text-red-600" 
                          : "text-gray-600"
                    )}>
                      ₹{selectedMember.balance.toLocaleString()}
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="py-2">
                    <CardTitle className="text-base">{language === 'english' ? 'Annual Interest' : 'వార్షిక వడ్డీ'}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className={cn(
                      "text-xl font-bold",
                      selectedMember.balance > 0 
                        ? "text-green-600" 
                        : selectedMember.balance < 0 
                          ? "text-red-600" 
                          : "text-gray-600"
                    )}>
                      ₹{calculateInterest(selectedMember.balance).toLocaleString()}
                      <span className="text-sm ml-2">
                        ({selectedMember.balance > 0 ? committeeInterest.deposit : committeeInterest.loan}%)
                      </span>
                    </p>
                  </CardContent>
                </Card>
              </div>

              {/* Transactions */}
              <div>
                <h3 className="text-lg font-medium mb-2">
                  {language === 'english' ? 'Transaction History' : 'లావాదేవీ చరిత్ర'}
                </h3>
                
                {selectedMember.transactions.length > 0 ? (
                  <div className="border rounded-lg overflow-hidden">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>{language === 'english' ? 'Date' : 'తేదీ'}</TableHead>
                          <TableHead>{language === 'english' ? 'Description' : 'వివరణ'}</TableHead>
                          <TableHead>{language === 'english' ? 'Amount' : 'మొత్తం'}</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {[...selectedMember.transactions]
                          .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                          .map((transaction) => (
                            <TableRow key={transaction.id}>
                              <TableCell>{formatDate(transaction.date)}</TableCell>
                              <TableCell>{transaction.description}</TableCell>
                              <TableCell className={transaction.amount > 0 ? "text-green-600" : "text-red-600"}>
                                <span className="flex items-center">
                                  {transaction.amount > 0 ? <ArrowRight className="h-3 w-3 rotate-[-135deg] mr-1" /> : <ArrowRight className="h-3 w-3 rotate-45 mr-1" />}
                                  ₹{Math.abs(transaction.amount).toLocaleString()}
                                </span>
                              </TableCell>
                            </TableRow>
                          ))}
                      </TableBody>
                    </Table>
                  </div>
                ) : (
                  <p className="text-muted-foreground">
                    {language === 'english' ? 'No transactions found' : 'లావాదేవీలు కనుగొనబడలేదు'}
                  </p>
                )}
              </div>

              <DialogFooter>
                <Button variant="outline" onClick={() => setIsViewDialogOpen(false)}>
                  {language === 'english' ? 'Close' : 'మూసివేయి'}
                </Button>
                <Button onClick={() => {
                  setIsViewDialogOpen(false);
                  openTransactionDialog(selectedMember.id);
                }}>
                  <Plus className="h-4 w-4 mr-1" />
                  {language === 'english' ? 'Add Transaction' : 'లావాదేవీని జోడించండి'}
                </Button>
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Add Transaction Dialog */}
      <Dialog open={isTransactionDialogOpen} onOpenChange={setIsTransactionDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle className="text-xl text-sangam-800">
              {language === 'english' ? 'Add Transaction' : 'లావాదేవీని జోడించండి'}
            </DialogTitle>
            <DialogDescription>
              {selectedMember && (
                <span>
                  {language === 'english' 
                    ? `Add a new transaction for ${selectedMember.name}` 
                    : `${selectedMember.name} కోసం కొత్త లావాదేవీని జోడించండి`}
                </span>
              )}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <Tabs defaultValue="credit" value={newTransactionType} onValueChange={setNewTransactionType}>
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="credit">
                  <CreditCard className="h-4 w-4 mr-2" />
                  {language === 'english' ? 'Credit' : 'జమ చేయండి'}
                </TabsTrigger>
                <TabsTrigger value="debit">
                  <Wallet className="h-4 w-4 mr-2" />
                  {language === 'english' ? 'Debit' : 'తీయండి'}
                </TabsTrigger>
              </TabsList>
              <TabsContent value="credit" className="pt-4">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="amount">{language === 'english' ? 'Amount' : 'మొత్తం'}</Label>
                    <div className="relative">
                      <span className="absolute left-3 top-2.5">₹</span>
                      <Input 
                        id="amount"
                        type="number"
                        placeholder="0.00"
                        className="pl-7"
                        value={newTransactionAmount}
                        onChange={(e) => setNewTransactionAmount(e.target.value)}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="description">{language === 'english' ? 'Description' : 'వివరణ'}</Label>
                    <Input 
                      id="description"
                      placeholder={language === 'english' ? 'Committee Deposit' : 'కమిటీ డిపాజిట్'}
                      value={newTransactionDescription}
                      onChange={(e) => setNewTransactionDescription(e.target.value)}
                    />
                  </div>
                </div>
              </TabsContent>
              <TabsContent value="debit" className="pt-4">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="amount">{language === 'english' ? 'Amount' : 'మొత్తం'}</Label>
                    <div className="relative">
                      <span className="absolute left-3 top-2.5">₹</span>
                      <Input 
                        id="amount"
                        type="number"
                        placeholder="0.00"
                        className="pl-7"
                        value={newTransactionAmount}
                        onChange={(e) => setNewTransactionAmount(e.target.value)}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="description">{language === 'english' ? 'Description' : 'వివరణ'}</Label>
                    <Input 
                      id="description"
                      placeholder={language === 'english' ? 'Loan Withdrawal' : 'రుణ ఉపసంహరణ'}
                      value={newTransactionDescription}
                      onChange={(e) => setNewTransactionDescription(e.target.value)}
                    />
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsTransactionDialogOpen(false)}>
              {language === 'english' ? 'Cancel' : 'రద్దు చేయండి'}
            </Button>
            <Button onClick={handleAddTransaction}>
              {language === 'english' ? 'Add Transaction' : 'లావాదేవీని జోడించండి'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default WattaPage;
