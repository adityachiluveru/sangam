
import { SidebarProvider } from '@/components/ui/sidebar';
import { AppSidebar } from '@/components/AppSidebar';
import React, { useState } from 'react';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  CardFooter
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { CalendarIcon, Download, FileText, Filter, Calendar } from "lucide-react";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  AreaChart,
  Area
} from 'recharts';
import { toast } from "sonner";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { format } from "date-fns";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

const monthlyData = [
  { name: 'Jan', loans: 50000, payments: 30000 },
  { name: 'Feb', loans: 60000, payments: 35000 },
  { name: 'Mar', loans: 45000, payments: 40000 },
  { name: 'Apr', loans: 75000, payments: 42000 },
  { name: 'May', loans: 55000, payments: 48000 },
];

const paymentStatusData = [
  { name: 'Paid', value: 68, color: '#10b981' },
  { name: 'Pending', value: 32, color: '#f59e0b' },
];

const membershipData = [
  { name: 'Active Members', value: 85, color: '#3b82f6' },
  { name: 'Inactive Members', value: 15, color: '#6b7280' },
];

const loanTypeData = [
  { name: 'Short Term', value: 45, color: '#8b5cf6' },
  { name: 'Medium Term', value: 35, color: '#ec4899' },
  { name: 'Long Term', value: 20, color: '#06b6d4' },
];

// Detailed data for loan analytics tab
const loanMonthlyTrends = [
  { month: 'Jan', value: 12, count: 4 },
  { month: 'Feb', value: 19, count: 6 },
  { month: 'Mar', value: 15, count: 5 },
  { month: 'Apr', value: 25, count: 7 },
  { month: 'May', value: 28, count: 8 },
  { month: 'Jun', value: 20, count: 6 },
];

const loanReasonData = [
  { name: 'Business', value: 40, color: '#3b82f6' },
  { name: 'Education', value: 25, color: '#10b981' },
  { name: 'Medical', value: 15, color: '#f59e0b' },
  { name: 'Home', value: 12, color: '#8b5cf6' },
  { name: 'Other', value: 8, color: '#6b7280' },
];

// Detailed data for payment analytics tab
const paymentTrendsData = [
  { month: 'Jan', onTime: 28, late: 4 },
  { month: 'Feb', onTime: 32, late: 5 },
  { month: 'Mar', onTime: 30, late: 3 },
  { month: 'Apr', onTime: 34, late: 2 },
  { month: 'May', onTime: 36, late: 6 },
];

const paymentMethodData = [
  { name: 'Cash', value: 45, color: '#3b82f6' },
  { name: 'UPI', value: 35, color: '#10b981' },
  { name: 'Bank Transfer', value: 20, color: '#f59e0b' },
];

// Detailed data for member analytics tab
const memberGrowthData = [
  { month: 'Jan', members: 50 },
  { month: 'Feb', members: 52 },
  { month: 'Mar', members: 58 },
  { month: 'Apr', members: 65 },
  { month: 'May', members: 72 },
  { month: 'Jun', members: 78 },
];

const memberActivityData = [
  { name: 'Very Active', value: 35, color: '#10b981' },
  { name: 'Active', value: 40, color: '#3b82f6' },
  { name: 'Occasional', value: 15, color: '#f59e0b' },
  { name: 'Inactive', value: 10, color: '#6b7280' },
];

const Reports = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [dateRange, setDateRange] = useState("thisMonth");
  const [showDatePickerDialog, setShowDatePickerDialog] = useState(false);
  const [customStartDate, setCustomStartDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [customEndDate, setCustomEndDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [showGenerateReportDialog, setShowGenerateReportDialog] = useState(false);
  const [reportType, setReportType] = useState("summary");

  const getDateRangeText = () => {
    switch(dateRange) {
      case "thisWeek":
        return "This Week";
      case "thisMonth":
        return "This Month";
      case "lastMonth":
        return "Last Month";
      case "lastQuarter":
        return "Last Quarter";
      case "thisYear":
        return "This Year";
      case "custom":
        return `${format(new Date(customStartDate), 'dd/MM/yyyy')} - ${format(new Date(customEndDate), 'dd/MM/yyyy')}`;
      default:
        return "This Month";
    }
  };

  const handleGenerateReport = () => {
    toast.success(`${reportType.charAt(0).toUpperCase() + reportType.slice(1)} report generated successfully!`);
    setShowGenerateReportDialog(false);
  };

  const handleExport = () => {
    toast.success(`${activeTab.charAt(0).toUpperCase() + activeTab.slice(1)} data exported successfully!`);
  };

  const handleApplyDateRange = () => {
    setDateRange("custom");
    setShowDatePickerDialog(false);
    toast.success("Date range applied successfully");
  };

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full">
        <AppSidebar />
        <div className="flex-1 pl-16 md:pl-64">
          <div className="p-6 max-w-7xl mx-auto animate-fade-in">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
              <div>
                <h1 className="text-2xl font-bold">Reports</h1>
                <p className="text-muted-foreground">Detailed analytics and reports</p>
              </div>
              <div className="flex gap-2 flex-wrap justify-end">
                <Dialog open={showDatePickerDialog} onOpenChange={setShowDatePickerDialog}>
                  <DialogTrigger asChild>
                    <Button variant="outline" className="flex items-center gap-2">
                      <CalendarIcon size={16} />
                      <span>{getDateRangeText()}</span>
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-[425px]">
                    <DialogHeader>
                      <DialogTitle>Select Date Range</DialogTitle>
                      <DialogDescription>
                        Choose a predefined range or select custom dates
                      </DialogDescription>
                    </DialogHeader>
                    <div className="grid gap-4 py-4">
                      <div className="grid grid-cols-1 gap-2">
                        <Button 
                          variant={dateRange === "thisWeek" ? "default" : "outline"}
                          className="justify-start"
                          onClick={() => setDateRange("thisWeek")}
                        >
                          This Week
                        </Button>
                        <Button 
                          variant={dateRange === "thisMonth" ? "default" : "outline"}
                          className="justify-start"
                          onClick={() => setDateRange("thisMonth")}
                        >
                          This Month
                        </Button>
                        <Button 
                          variant={dateRange === "lastMonth" ? "default" : "outline"}
                          className="justify-start"
                          onClick={() => setDateRange("lastMonth")}
                        >
                          Last Month
                        </Button>
                        <Button 
                          variant={dateRange === "lastQuarter" ? "default" : "outline"}
                          className="justify-start"
                          onClick={() => setDateRange("lastQuarter")}
                        >
                          Last Quarter
                        </Button>
                        <Button 
                          variant={dateRange === "thisYear" ? "default" : "outline"}
                          className="justify-start"
                          onClick={() => setDateRange("thisYear")}
                        >
                          This Year
                        </Button>
                      </div>
                      <div className="mt-2 pt-2 border-t">
                        <h4 className="text-sm font-medium mb-3">Custom Range</h4>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="grid gap-2">
                            <Label htmlFor="startDate">Start Date</Label>
                            <Input 
                              id="startDate" 
                              type="date" 
                              value={customStartDate}
                              onChange={(e) => setCustomStartDate(e.target.value)}
                            />
                          </div>
                          <div className="grid gap-2">
                            <Label htmlFor="endDate">End Date</Label>
                            <Input 
                              id="endDate" 
                              type="date" 
                              value={customEndDate}
                              onChange={(e) => setCustomEndDate(e.target.value)}
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setShowDatePickerDialog(false)}>
                        Cancel
                      </Button>
                      <Button onClick={handleApplyDateRange}>Apply Range</Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
                
                <Dialog open={showGenerateReportDialog} onOpenChange={setShowGenerateReportDialog}>
                  <DialogTrigger asChild>
                    <Button variant="outline" className="flex items-center gap-2">
                      <FileText size={16} />
                      <span>Generate Report</span>
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-[425px]">
                    <DialogHeader>
                      <DialogTitle>Generate Report</DialogTitle>
                      <DialogDescription>
                        Select the type of report you want to generate
                      </DialogDescription>
                    </DialogHeader>
                    <div className="py-4">
                      <Select value={reportType} onValueChange={setReportType}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select report type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="summary">Summary Report</SelectItem>
                          <SelectItem value="detailed">Detailed Report</SelectItem>
                          <SelectItem value="financial">Financial Statement</SelectItem>
                          <SelectItem value="member">Member Activity Report</SelectItem>
                          <SelectItem value="loan">Loan Status Report</SelectItem>
                        </SelectContent>
                      </Select>
                      
                      <div className="mt-4 bg-muted/30 p-3 rounded-md">
                        <h4 className="text-sm font-medium mb-1">Report Details</h4>
                        <p className="text-sm text-muted-foreground">
                          {reportType === "summary" && "An overview of key metrics and performance indicators."}
                          {reportType === "detailed" && "In-depth analysis of all transactions and activities."}
                          {reportType === "financial" && "Complete financial statement including balance sheet."}
                          {reportType === "member" && "Detailed report on member activities and contributions."}
                          {reportType === "loan" && "Comprehensive analysis of all loans and their status."}
                        </p>
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setShowGenerateReportDialog(false)}>
                        Cancel
                      </Button>
                      <Button onClick={handleGenerateReport}>Generate</Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
                
                <Button className="flex items-center gap-2" onClick={handleExport}>
                  <Download size={16} />
                  <span>Export</span>
                </Button>
              </div>
            </div>
            
            <Tabs defaultValue="overview" onValueChange={setActiveTab}>
              <TabsList className="mb-6">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="loans">Loans</TabsTrigger>
                <TabsTrigger value="payments">Payments</TabsTrigger>
                <TabsTrigger value="members">Members</TabsTrigger>
              </TabsList>
              
              <TabsContent value="overview" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Monthly Financial Activity</CardTitle>
                    <CardDescription>
                      Comparison of loans issued vs payments received
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          data={monthlyData}
                          margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="name" />
                          <YAxis />
                          <Tooltip formatter={(value) => `₹${value.toLocaleString()}`} />
                          <Legend />
                          <Bar dataKey="loans" name="Loans Issued" fill="#8b5cf6" />
                          <Bar dataKey="payments" name="Payments Received" fill="#10b981" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-between text-sm text-muted-foreground">
                    <div>Total Loans: ₹285,000</div>
                    <div>Total Payments: ₹195,000</div>
                  </CardFooter>
                </Card>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base">Payment Status</CardTitle>
                      <CardDescription>
                        Paid vs pending payments
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="h-64 flex items-center justify-center">
                        <ResponsiveContainer width="100%" height="100%">
                          <PieChart>
                            <Pie
                              data={paymentStatusData}
                              cx="50%"
                              cy="50%"
                              labelLine={false}
                              outerRadius={80}
                              fill="#8884d8"
                              dataKey="value"
                              label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                            >
                              {paymentStatusData.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={entry.color} />
                              ))}
                            </Pie>
                            <Tooltip formatter={(value) => `${value}%`} />
                          </PieChart>
                        </ResponsiveContainer>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base">Membership Status</CardTitle>
                      <CardDescription>
                        Active vs inactive members
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="h-64 flex items-center justify-center">
                        <ResponsiveContainer width="100%" height="100%">
                          <PieChart>
                            <Pie
                              data={membershipData}
                              cx="50%"
                              cy="50%"
                              labelLine={false}
                              outerRadius={80}
                              fill="#8884d8"
                              dataKey="value"
                              label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                            >
                              {membershipData.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={entry.color} />
                              ))}
                            </Pie>
                            <Tooltip formatter={(value) => `${value}%`} />
                          </PieChart>
                        </ResponsiveContainer>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base">Loan Types</CardTitle>
                      <CardDescription>
                        Distribution by loan duration
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="h-64 flex items-center justify-center">
                        <ResponsiveContainer width="100%" height="100%">
                          <PieChart>
                            <Pie
                              data={loanTypeData}
                              cx="50%"
                              cy="50%"
                              labelLine={false}
                              outerRadius={80}
                              fill="#8884d8"
                              dataKey="value"
                              label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                            >
                              {loanTypeData.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={entry.color} />
                              ))}
                            </Pie>
                            <Tooltip formatter={(value) => `${value}%`} />
                          </PieChart>
                        </ResponsiveContainer>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
              
              <TabsContent value="loans" className="space-y-6">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-2xl font-bold">Loan Analytics</h2>
                  <Select defaultValue="value">
                    <SelectTrigger className="w-[180px]">
                      <SelectValue placeholder="View by" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="value">Loan Value</SelectItem>
                      <SelectItem value="count">Loan Count</SelectItem>
                      <SelectItem value="duration">Loan Duration</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <Card className="mb-6">
                  <CardHeader>
                    <CardTitle>Monthly Loan Trends</CardTitle>
                    <CardDescription>Growth in loan disbursements over time</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart
                          data={loanMonthlyTrends}
                          margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="month" />
                          <YAxis />
                          <Tooltip />
                          <Legend />
                          <Area 
                            type="monotone" 
                            dataKey="value" 
                            name="Loan Amount (₹ 10,000s)" 
                            stroke="#8b5cf6" 
                            fill="#c4b5fd" 
                          />
                          <Area 
                            type="monotone" 
                            dataKey="count" 
                            name="Number of Loans" 
                            stroke="#06b6d4" 
                            fill="#a5f3fc" 
                          />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Loan Purpose Distribution</CardTitle>
                      <CardDescription>Breakdown of loans by purpose</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="h-80">
                        <ResponsiveContainer width="100%" height="100%">
                          <PieChart>
                            <Pie
                              data={loanReasonData}
                              cx="50%"
                              cy="50%"
                              labelLine={false}
                              outerRadius={100}
                              fill="#8884d8"
                              dataKey="value"
                              label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                            >
                              {loanReasonData.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={entry.color} />
                              ))}
                            </Pie>
                            <Tooltip formatter={(value) => `${value}%`} />
                            <Legend verticalAlign="bottom" height={36} />
                          </PieChart>
                        </ResponsiveContainer>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader>
                      <CardTitle>Loan Performance Metrics</CardTitle>
                      <CardDescription>Key indicators of loan health</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="p-4 rounded-lg border bg-muted/20">
                          <p className="text-sm text-muted-foreground">Average Loan Size</p>
                          <p className="text-xl font-bold">₹35,000</p>
                        </div>
                        <div className="p-4 rounded-lg border bg-muted/20">
                          <p className="text-sm text-muted-foreground">Repayment Rate</p>
                          <p className="text-xl font-bold text-green-600">94%</p>
                        </div>
                        <div className="p-4 rounded-lg border bg-muted/20">
                          <p className="text-sm text-muted-foreground">Avg Interest Rate</p>
                          <p className="text-xl font-bold">12.5%</p>
                        </div>
                        <div className="p-4 rounded-lg border bg-muted/20">
                          <p className="text-sm text-muted-foreground">Default Rate</p>
                          <p className="text-xl font-bold text-amber-600">3.2%</p>
                        </div>
                      </div>
                      <div className="mt-6">
                        <Button 
                          variant="outline" 
                          className="w-full"
                          onClick={() => toast.success("Detailed loan analytics downloaded")}
                        >
                          Download Detailed Report
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
              
              <TabsContent value="payments" className="space-y-6">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-2xl font-bold">Payment Analytics</h2>
                  <Button variant="outline" onClick={() => toast.success("Report filters applied")}>
                    <Filter className="h-4 w-4 mr-2" />
                    <span>Filter</span>
                  </Button>
                </div>
                
                <Card className="mb-6">
                  <CardHeader>
                    <CardTitle>Payment Trends</CardTitle>
                    <CardDescription>On-time vs late payments over time</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          data={paymentTrendsData}
                          margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="month" />
                          <YAxis />
                          <Tooltip />
                          <Legend />
                          <Bar dataKey="onTime" name="On-Time Payments" stackId="a" fill="#10b981" />
                          <Bar dataKey="late" name="Late Payments" stackId="a" fill="#f59e0b" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Payment Methods</CardTitle>
                      <CardDescription>Breakdown of payment methods used</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="h-80">
                        <ResponsiveContainer width="100%" height="100%">
                          <PieChart>
                            <Pie
                              data={paymentMethodData}
                              cx="50%"
                              cy="50%"
                              labelLine={false}
                              outerRadius={100}
                              fill="#8884d8"
                              dataKey="value"
                              label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                            >
                              {paymentMethodData.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={entry.color} />
                              ))}
                            </Pie>
                            <Tooltip formatter={(value) => `${value}%`} />
                            <Legend verticalAlign="bottom" height={36} />
                          </PieChart>
                        </ResponsiveContainer>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader>
                      <CardTitle>Collection Efficiency</CardTitle>
                      <CardDescription>Key performance indicators for collections</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="p-4 rounded-lg border bg-muted/20">
                          <p className="text-sm text-muted-foreground">Collection Rate</p>
                          <p className="text-xl font-bold text-green-600">94.5%</p>
                        </div>
                        <div className="p-4 rounded-lg border bg-muted/20">
                          <p className="text-sm text-muted-foreground">Avg Days to Pay</p>
                          <p className="text-xl font-bold">2.3 days</p>
                        </div>
                        <div className="p-4 rounded-lg border bg-muted/20">
                          <p className="text-sm text-muted-foreground">On-time Rate</p>
                          <p className="text-xl font-bold text-blue-600">87%</p>
                        </div>
                        <div className="p-4 rounded-lg border bg-muted/20">
                          <p className="text-sm text-muted-foreground">Recurring Payers</p>
                          <p className="text-xl font-bold">76%</p>
                        </div>
                      </div>
                      <div className="mt-6">
                        <Button 
                          className="w-full"
                          onClick={() => toast.success("Payment reminders sent to all due members")}
                        >
                          Send Payment Reminders
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
              
              <TabsContent value="members" className="space-y-6">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-2xl font-bold">Member Analytics</h2>
                  <Button
                    variant="outline"
                    className="flex items-center gap-2"
                    onClick={() => toast.success("Member data being refreshed...")}
                  >
                    <Calendar size={16} />
                    <span>Quarterly View</span>
                  </Button>
                </div>
                
                <Card className="mb-6">
                  <CardHeader>
                    <CardTitle>Membership Growth</CardTitle>
                    <CardDescription>Growth in membership over time</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart
                          data={memberGrowthData}
                          margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="month" />
                          <YAxis />
                          <Tooltip />
                          <Legend />
                          <Line 
                            type="monotone" 
                            dataKey="members" 
                            name="Total Members" 
                            stroke="#8b5cf6" 
                            strokeWidth={2} 
                            activeDot={{ r: 8 }} 
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Member Activity</CardTitle>
                      <CardDescription>Member participation levels</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="h-80">
                        <ResponsiveContainer width="100%" height="100%">
                          <PieChart>
                            <Pie
                              data={memberActivityData}
                              cx="50%"
                              cy="50%"
                              labelLine={false}
                              outerRadius={100}
                              fill="#8884d8"
                              dataKey="value"
                              label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                            >
                              {memberActivityData.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={entry.color} />
                              ))}
                            </Pie>
                            <Tooltip formatter={(value) => `${value}%`} />
                            <Legend verticalAlign="bottom" height={36} />
                          </PieChart>
                        </ResponsiveContainer>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader>
                      <CardTitle>Member Metrics</CardTitle>
                      <CardDescription>Key statistics about membership</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="p-4 rounded-lg border bg-muted/20">
                          <p className="text-sm text-muted-foreground">Total Members</p>
                          <p className="text-xl font-bold">78</p>
                        </div>
                        <div className="p-4 rounded-lg border bg-muted/20">
                          <p className="text-sm text-muted-foreground">New This Month</p>
                          <p className="text-xl font-bold text-green-600">+6</p>
                        </div>
                        <div className="p-4 rounded-lg border bg-muted/20">
                          <p className="text-sm text-muted-foreground">Retention Rate</p>
                          <p className="text-xl font-bold text-blue-600">96%</p>
                        </div>
                        <div className="p-4 rounded-lg border bg-muted/20">
                          <p className="text-sm text-muted-foreground">Avg Member Age</p>
                          <p className="text-xl font-bold">42</p>
                        </div>
                      </div>
                      <div className="mt-6">
                        <Button 
                          variant="outline" 
                          className="w-full"
                          onClick={() => toast.success("Members directory downloaded")}
                        >
                          Download Members Directory
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </SidebarProvider>
  );
};

export default Reports;
