
import { SidebarProvider } from '@/components/ui/sidebar';
import { AppSidebar } from '@/components/AppSidebar';
import React, { useState } from 'react';
import { 
  Table, 
  TableHeader, 
  TableRow, 
  TableHead, 
  TableBody, 
  TableCell 
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { 
  PlusCircle, 
  Eye, 
  Edit, 
  XCircle, 
  CreditCard, 
  Filter, 
  Download,
  ChevronDown,
  Clock,
  ChevronLeft,
  ChevronRight,
  Check,
  AlertCircle
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { StatCard } from "@/components/StatCard";
import { format, addMonths } from "date-fns";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const dummyLoans = [
  {
    id: 1,
    memberName: 'Rahul Sharma',
    amount: 50000,
    status: 'Active',
    installment: 2500,
    issueDate: '2025-04-05',
    duration: 24,
    paidAmount: 7500,
    nextDueDate: '2025-06-05',
    rate: 12,
  },
  {
    id: 2,
    memberName: 'Priya Singh',
    amount: 25000,
    status: 'Paid',
    installment: 1250,
    issueDate: '2025-03-15',
    duration: 12,
    paidAmount: 25000,
    nextDueDate: null,
    rate: 10,
  },
  {
    id: 3,
    memberName: 'Amit Patel',
    amount: 100000,
    status: 'Pending',
    installment: 5000,
    issueDate: '2025-05-01',
    duration: 24,
    paidAmount: 0,
    nextDueDate: '2025-06-01',
    rate: 11,
  },
  {
    id: 4,
    memberName: 'Meera Desai',
    amount: 75000,
    status: 'Active',
    installment: 3750,
    issueDate: '2025-04-20',
    duration: 24,
    paidAmount: 3750,
    nextDueDate: '2025-06-20',
    rate: 12,
  },
  {
    id: 5,
    memberName: 'Rajesh Kumar',
    amount: 200000,
    status: 'Active',
    installment: 10000,
    issueDate: '2025-05-10',
    duration: 24,
    paidAmount: 0,
    nextDueDate: '2025-06-10',
    rate: 12.5,
  },
  {
    id: 6,
    memberName: 'Sneha Verma',
    amount: 150000,
    status: 'Overdue',
    installment: 7500,
    issueDate: '2025-03-05',
    duration: 24,
    paidAmount: 15000,
    nextDueDate: '2025-05-05',
    rate: 12,
  },
];

// Upcoming payments for alert
const upcomingPayments = [
  {
    id: 101,
    memberName: 'Rajesh Kumar',
    amount: 10000,
    dueDate: '2025-05-15'
  },
  {
    id: 102,
    memberName: 'Meera Desai',
    amount: 3750,
    dueDate: '2025-05-20'
  },
  {
    id: 103,
    memberName: 'Rahul Sharma',
    amount: 2500,
    dueDate: '2025-05-25'
  }
];

const Loans = () => {
  const [loans, setLoans] = useState(dummyLoans);
  const [activeTab, setActiveTab] = useState("all");
  const [viewDetails, setViewDetails] = useState(null);
  const [showAddLoanDialog, setShowAddLoanDialog] = useState(false);
  const [showUpcomingPayments, setShowUpcomingPayments] = useState(false);
  const [newLoan, setNewLoan] = useState({
    memberName: '',
    amount: '',
    duration: '24',
    rate: '12',
    purpose: ''
  });
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 4;

  // Calculate summary metrics
  const totalActiveLoanAmount = loans
    .filter(loan => loan.status === 'Active' || loan.status === 'Overdue')
    .reduce((sum, loan) => sum + loan.amount, 0);
    
  const totalPaidAmount = loans
    .reduce((sum, loan) => sum + loan.paidAmount, 0);
    
  const totalDisbursedAmount = loans
    .reduce((sum, loan) => sum + loan.amount, 0);
    
  const pendingInstallments = loans
    .filter(loan => loan.status === 'Active' || loan.status === 'Overdue')
    .reduce((sum, loan) => {
      const remainingAmount = loan.amount - loan.paidAmount;
      return sum + remainingAmount;
    }, 0);

  const overdueLoans = loans.filter(loan => loan.status === 'Overdue').length;

  // Filter loans based on active tab
  const getFilteredLoans = () => {
    switch(activeTab) {
      case "active":
        return loans.filter(loan => loan.status === 'Active');
      case "paid":
        return loans.filter(loan => loan.status === 'Paid');
      case "pending":
        return loans.filter(loan => loan.status === 'Pending');
      case "overdue":
        return loans.filter(loan => loan.status === 'Overdue');
      default:
        return loans;
    }
  };

  const filteredLoans = getFilteredLoans();
  
  // Paginate loans
  const paginatedLoans = filteredLoans.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );
  
  const totalPages = Math.ceil(filteredLoans.length / itemsPerPage);

  const getStatusColor = (status: string) => {
    switch(status.toLowerCase()) {
      case 'active':
        return 'bg-blue-100 text-blue-800';
      case 'paid':
        return 'bg-green-100 text-green-800';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'overdue':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const handleAddLoan = () => {
    if (!newLoan.memberName || !newLoan.amount) {
      toast.error("Member name and loan amount are required");
      return;
    }

    const newLoanData = {
      id: loans.length + 1,
      memberName: newLoan.memberName,
      amount: parseInt(newLoan.amount),
      status: 'Pending',
      installment: Math.ceil(parseInt(newLoan.amount) / parseInt(newLoan.duration)),
      issueDate: format(new Date(), 'yyyy-MM-dd'),
      duration: parseInt(newLoan.duration),
      paidAmount: 0,
      nextDueDate: format(addMonths(new Date(), 1), 'yyyy-MM-dd'),
      rate: parseFloat(newLoan.rate),
    };

    setLoans([...loans, newLoanData]);
    setShowAddLoanDialog(false);
    toast.success(`New loan for ${newLoan.memberName} has been created`);

    setNewLoan({
      memberName: '',
      amount: '',
      duration: '24',
      rate: '12',
      purpose: ''
    });
  };

  const handleViewLoanDetails = (loan) => {
    setViewDetails(loan);
  };

  const handleMakePayment = (loanId) => {
    toast.success("Payment feature will be available soon");
  };

  const handleApproveLoan = (loanId) => {
    const updatedLoans = loans.map(loan => {
      if (loan.id === loanId) {
        return {...loan, status: 'Active'};
      }
      return loan;
    });

    setLoans(updatedLoans);
    toast.success("Loan has been approved");
  };

  const handleCloseLoan = (loanId) => {
    const loan = loans.find(loan => loan.id === loanId);
    if (!loan) return;

    const updatedLoans = loans.map(l => {
      if (l.id === loanId) {
        return {...l, status: 'Paid', paidAmount: l.amount, nextDueDate: null};
      }
      return l;
    });

    setLoans(updatedLoans);
    toast.success(`Loan for ${loan.memberName} has been closed`);
  };

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full">
        <AppSidebar />
        <div className="flex-1 pl-16 md:pl-64">
          <div className="p-6 max-w-7xl mx-auto animate-fade-in">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
              <div>
                <h1 className="text-2xl font-bold">Loans</h1>
                <p className="text-muted-foreground">Manage community loans and payments</p>
              </div>
              <Button className="flex items-center gap-2" onClick={() => setShowAddLoanDialog(true)}>
                <PlusCircle size={16} />
                <span>Add New Loan</span>
              </Button>
            </div>
            
            {/* Loan Statistics Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <StatCard
                title="Total Active Loans"
                value={`₹${totalActiveLoanAmount.toLocaleString()}`}
                description={`${loans.filter(l => l.status === 'Active').length} active loans`}
                className="bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-100"
              />
              
              <StatCard
                title="Collected Amount"
                value={`₹${totalPaidAmount.toLocaleString()}`}
                description="Total repayments received"
                className="bg-gradient-to-br from-green-50 to-emerald-50 border-green-100"
              />
              
              <StatCard
                title="Remaining Collections"
                value={`₹${pendingInstallments.toLocaleString()}`}
                description="Yet to be collected"
                className="bg-gradient-to-br from-amber-50 to-yellow-50 border-amber-100"
              />
              
              <StatCard
                title="Overdue Loans"
                value={overdueLoans}
                description="Require immediate attention"
                className="bg-gradient-to-br from-red-50 to-rose-50 border-red-100"
              />
            </div>

            {/* Upcoming Payments Alert Card */}
            <div className="mb-6 bg-amber-50 border border-amber-200 p-4 rounded-lg flex items-center justify-between">
              <div className="flex items-center">
                <Clock className="w-5 h-5 text-amber-500 mr-2" />
                <div>
                  <h3 className="font-medium">Upcoming Payments Due</h3>
                  <p className="text-sm text-muted-foreground">{upcomingPayments.length} installments due in the next 7 days</p>
                </div>
              </div>
              <Button 
                variant="outline" 
                className="border-amber-200 text-amber-700 hover:bg-amber-100"
                onClick={() => setShowUpcomingPayments(true)}
              >
                View Details
              </Button>
            </div>
            
            {/* Loans Table */}
            <div className="bg-white rounded-lg shadow-sm border">
              <div className="p-4 border-b">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                  <h2 className="text-lg font-medium">Loan Register</h2>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" className="flex items-center gap-1">
                      <Filter size={14} />
                      <span>Filter</span>
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="flex items-center gap-1"
                      onClick={() => toast.success("Loan data exported successfully")}
                    >
                      <Download size={14} />
                      <span>Export</span>
                    </Button>
                  </div>
                </div>

                <Tabs 
                  value={activeTab} 
                  onValueChange={setActiveTab} 
                  className="mt-4"
                >
                  <TabsList className="grid grid-cols-2 sm:grid-cols-5 gap-2 bg-muted/50">
                    <TabsTrigger value="all">All</TabsTrigger>
                    <TabsTrigger value="active">Active</TabsTrigger>
                    <TabsTrigger value="pending">Pending</TabsTrigger>
                    <TabsTrigger value="paid">Paid</TabsTrigger>
                    <TabsTrigger value="overdue">Overdue</TabsTrigger>
                  </TabsList>
                </Tabs>
              </div>
              
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Member Name</TableHead>
                      <TableHead>Amount (₹)</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Rate (%)</TableHead>
                      <TableHead>Monthly EMI</TableHead>
                      <TableHead>Duration</TableHead>
                      <TableHead>Issue Date</TableHead>
                      <TableHead>Next Due</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {paginatedLoans.map((loan) => (
                      <TableRow key={loan.id}>
                        <TableCell className="font-medium">{loan.memberName}</TableCell>
                        <TableCell>₹{loan.amount.toLocaleString()}</TableCell>
                        <TableCell>
                          <Badge variant="outline" className={getStatusColor(loan.status)}>
                            {loan.status}
                          </Badge>
                        </TableCell>
                        <TableCell>{loan.rate}%</TableCell>
                        <TableCell>₹{loan.installment.toLocaleString()}</TableCell>
                        <TableCell>{loan.duration} months</TableCell>
                        <TableCell>{format(new Date(loan.issueDate), "dd MMM yyyy")}</TableCell>
                        <TableCell>
                          {loan.nextDueDate 
                            ? format(new Date(loan.nextDueDate), "dd MMM yyyy")
                            : "-"}
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              title="View Details"
                              onClick={() => handleViewLoanDetails(loan)}
                            >
                              <Eye size={16} />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              title="Edit Loan"
                              onClick={() => toast.info("Edit loan feature coming soon")}
                            >
                              <Edit size={16} />
                            </Button>
                            {loan.status === 'Pending' ? (
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                title="Approve Loan"
                                onClick={() => handleApproveLoan(loan.id)}
                              >
                                <Check size={16} />
                              </Button>
                            ) : (
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                title="Add Payment"
                                onClick={() => handleMakePayment(loan.id)}
                              >
                                <CreditCard size={16} />
                              </Button>
                            )}
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              title="Close Loan"
                              onClick={() => handleCloseLoan(loan.id)}
                            >
                              <XCircle size={16} />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                    {paginatedLoans.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={9} className="text-center py-6 text-muted-foreground">
                          No loans found for the selected filter
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
              
              <div className="p-4 border-t flex flex-col sm:flex-row sm:items-center sm:justify-between text-sm text-muted-foreground">
                <div>
                  Showing {paginatedLoans.length} of {filteredLoans.length} loans
                </div>
                <div className="flex items-center gap-2 mt-2 sm:mt-0">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                    disabled={currentPage === 1}
                  >
                    <ChevronLeft size={16} /> Previous
                  </Button>
                  <span>
                    Page {currentPage} of {totalPages || 1}
                  </span>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                    disabled={currentPage >= totalPages}
                  >
                    Next <ChevronRight size={16} />
                  </Button>
                </div>
              </div>
            </div>

            {/* Add Loan Dialog */}
            <Dialog open={showAddLoanDialog} onOpenChange={setShowAddLoanDialog}>
              <DialogContent className="sm:max-w-[525px]">
                <DialogHeader>
                  <DialogTitle>Create New Loan</DialogTitle>
                  <DialogDescription>
                    Fill in the loan details for the member
                  </DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="memberName" className="text-right">
                      Member Name
                    </Label>
                    <Input
                      id="memberName"
                      value={newLoan.memberName}
                      onChange={(e) => setNewLoan({...newLoan, memberName: e.target.value})}
                      className="col-span-3"
                      placeholder="Select or enter member name"
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="amount" className="text-right">
                      Loan Amount
                    </Label>
                    <Input
                      id="amount"
                      type="number"
                      value={newLoan.amount}
                      onChange={(e) => setNewLoan({...newLoan, amount: e.target.value})}
                      className="col-span-3"
                      placeholder="Enter amount in ₹"
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="duration" className="text-right">
                      Duration
                    </Label>
                    <Select 
                      value={newLoan.duration} 
                      onValueChange={(value) => setNewLoan({...newLoan, duration: value})}
                    >
                      <SelectTrigger className="col-span-3">
                        <SelectValue placeholder="Select loan duration" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="6">6 Months</SelectItem>
                        <SelectItem value="12">12 Months</SelectItem>
                        <SelectItem value="24">24 Months</SelectItem>
                        <SelectItem value="36">36 Months</SelectItem>
                        <SelectItem value="48">48 Months</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="rate" className="text-right">
                      Interest Rate (%)
                    </Label>
                    <Input
                      id="rate"
                      type="number"
                      value={newLoan.rate}
                      onChange={(e) => setNewLoan({...newLoan, rate: e.target.value})}
                      className="col-span-3"
                      placeholder="Enter interest rate"
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="purpose" className="text-right">
                      Purpose
                    </Label>
                    <Input
                      id="purpose"
                      value={newLoan.purpose}
                      onChange={(e) => setNewLoan({...newLoan, purpose: e.target.value})}
                      className="col-span-3"
                      placeholder="Enter loan purpose"
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setShowAddLoanDialog(false)}>Cancel</Button>
                  <Button onClick={handleAddLoan}>Create Loan</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>

            {/* View Loan Details Dialog */}
            <Dialog open={!!viewDetails} onOpenChange={() => setViewDetails(null)}>
              <DialogContent className="sm:max-w-[600px]">
                {viewDetails && (
                  <>
                    <DialogHeader>
                      <DialogTitle>Loan Details</DialogTitle>
                      <DialogDescription>
                        Complete information about this loan
                      </DialogDescription>
                    </DialogHeader>
                    <div className="py-4">
                      <div className="mb-4 pb-4 border-b">
                        <h3 className="text-lg font-medium mb-2">Member Information</h3>
                        <p className="mb-1"><span className="font-semibold">Name:</span> {viewDetails.memberName}</p>
                      </div>
                      
                      <div className="mb-4 pb-4 border-b">
                        <h3 className="text-lg font-medium mb-2">Loan Summary</h3>
                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <p className="text-sm text-muted-foreground">Principal Amount</p>
                            <p className="font-bold text-lg">₹{viewDetails.amount.toLocaleString()}</p>
                          </div>
                          <div>
                            <p className="text-sm text-muted-foreground">Status</p>
                            <Badge className={getStatusColor(viewDetails.status)}>
                              {viewDetails.status}
                            </Badge>
                          </div>
                          <div>
                            <p className="text-sm text-muted-foreground">Monthly Installment</p>
                            <p>₹{viewDetails.installment.toLocaleString()}</p>
                          </div>
                          <div>
                            <p className="text-sm text-muted-foreground">Interest Rate</p>
                            <p>{viewDetails.rate}% per annum</p>
                          </div>
                          <div>
                            <p className="text-sm text-muted-foreground">Issued On</p>
                            <p>{format(new Date(viewDetails.issueDate), "dd MMM yyyy")}</p>
                          </div>
                          <div>
                            <p className="text-sm text-muted-foreground">Duration</p>
                            <p>{viewDetails.duration} months</p>
                          </div>
                          <div>
                            <p className="text-sm text-muted-foreground">Paid Amount</p>
                            <p>₹{viewDetails.paidAmount.toLocaleString()}</p>
                          </div>
                          <div>
                            <p className="text-sm text-muted-foreground">Remaining Balance</p>
                            <p>₹{(viewDetails.amount - viewDetails.paidAmount).toLocaleString()}</p>
                          </div>
                        </div>
                      </div>
                      
                      <div className="mb-4">
                        <h3 className="text-lg font-medium mb-2">Payment Schedule</h3>
                        {viewDetails.status === 'Paid' ? (
                          <div className="text-center py-3 bg-green-50 rounded-lg">
                            <Check className="w-8 h-8 text-green-500 mx-auto mb-2" />
                            <p className="text-green-600 font-medium">This loan has been fully paid</p>
                          </div>
                        ) : (
                          <div className="flex justify-between items-center p-3 bg-blue-50 rounded-lg">
                            <div>
                              <p className="text-sm text-muted-foreground">Next Payment Due</p>
                              <p className="font-medium">
                                {viewDetails.nextDueDate ? format(new Date(viewDetails.nextDueDate), "dd MMM yyyy") : '-'}
                              </p>
                            </div>
                            <Button 
                              variant="outline"
                              onClick={() => toast.success("Payment recording feature coming soon")}
                            >
                              Record Payment
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>
                    <DialogFooter className="gap-2">
                      {viewDetails.status === 'Pending' && (
                        <Button 
                          className="bg-green-600 hover:bg-green-700"
                          onClick={() => {
                            handleApproveLoan(viewDetails.id);
                            setViewDetails(null);
                          }}
                        >
                          <Check className="h-4 w-4 mr-2" />
                          Approve Loan
                        </Button>
                      )}
                      
                      {(viewDetails.status === 'Active' || viewDetails.status === 'Overdue') && (
                        <Button 
                          onClick={() => {
                            handleCloseLoan(viewDetails.id);
                            setViewDetails(null);
                          }}
                        >
                          <XCircle className="h-4 w-4 mr-2" />
                          Close Loan
                        </Button>
                      )}
                    </DialogFooter>
                  </>
                )}
              </DialogContent>
            </Dialog>

            {/* Upcoming Payments Dialog */}
            <Dialog open={showUpcomingPayments} onOpenChange={setShowUpcomingPayments}>
              <DialogContent className="sm:max-w-[600px]">
                <DialogHeader>
                  <DialogTitle>Upcoming Payments</DialogTitle>
                  <DialogDescription>
                    These payments are due in the next 7 days
                  </DialogDescription>
                </DialogHeader>
                <div className="py-4">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Member Name</TableHead>
                        <TableHead>Amount</TableHead>
                        <TableHead>Due Date</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {upcomingPayments.map(payment => (
                        <TableRow key={payment.id}>
                          <TableCell className="font-medium">{payment.memberName}</TableCell>
                          <TableCell>₹{payment.amount.toLocaleString()}</TableCell>
                          <TableCell>{format(new Date(payment.dueDate), "dd MMM yyyy")}</TableCell>
                          <TableCell>
                            <Button 
                              variant="outline" 
                              size="sm" 
                              className="flex items-center gap-1"
                              onClick={() => toast.success(`SMS reminder sent to ${payment.memberName}`)}
                            >
                              Send Reminder
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
                <DialogFooter>
                  <Button 
                    variant="outline" 
                    onClick={() => toast.success("Payment reminders sent to all members")}
                  >
                    Send All Reminders
                  </Button>
                  <Button onClick={() => setShowUpcomingPayments(false)}>Close</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </div>
    </SidebarProvider>
  );
};

export default Loans;
