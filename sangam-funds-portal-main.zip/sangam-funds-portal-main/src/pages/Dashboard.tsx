
import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { StatCard } from "@/components/StatCard";
import { Users, CreditCard, Wallet, TrendingUp, Clock, AlertTriangle } from "lucide-react";
import { Button } from '@/components/ui/button';
import { RecentActivity } from '@/components/RecentActivity';
import { NoticeCard } from '@/components/NoticeCard';
import { FundsChart } from '@/components/FundsChart';
import { MonthlyPaymentChart } from '@/components/MonthlyPaymentChart';
import { useNavigate } from 'react-router-dom';
import { toast } from "sonner";

const Dashboard = () => {
  const navigate = useNavigate();
  
  const [stats, setStats] = useState({
    members: 42,
    activeLoans: 18,
    availableFunds: '₹4,25,000',
    monthlyCollection: '₹85,000',
    issuedLoan: '₹2,10,000',
    pendingDues: '₹45,000'
  });
  
  // Handler functions to navigate to relevant sections
  const handleViewMembers = () => navigate('/members');
  const handleViewLoans = () => navigate('/loans');
  const handleViewTransactions = () => navigate('/transactions');
  
  const handleMarkAllPaid = () => {
    toast.success("All pending dues have been marked as paid");
  };
  
  const handleSendReminders = () => {
    toast.success("Payment reminders sent to all members with pending dues");
  };

  return (
    <div className="p-6 animate-fade-in">
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-8">
        <div>
          <h1 className="text-2xl font-bold mb-1">Dashboard</h1>
          <p className="text-muted-foreground">Welcome to your Sangam Community Portal</p>
        </div>
        <div className="mt-4 lg:mt-0">
          <Button className="bg-sangam-600 hover:bg-sangam-700">
            Add New Transaction
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6 mb-6">
        <StatCard
          title="Total Members"
          value={stats.members}
          description="Active community members"
          icon={<Users className="h-5 w-5 text-sangam-600" />}
          trend={{ value: 5, isPositive: true }}
          className="hover-scale"
          onClick={handleViewMembers}
        />
        <StatCard
          title="Active Loans"
          value={stats.activeLoans}
          description="Current active loans"
          icon={<CreditCard className="h-5 w-5 text-sangam-600" />}
          trend={{ value: 2, isPositive: true }}
          className="hover-scale"
          onClick={handleViewLoans}
        />
        <StatCard
          title="Available Funds"
          value={stats.availableFunds}
          description="Total Sangam funds"
          icon={<Wallet className="h-5 w-5 text-sangam-600" />}
          trend={{ value: 12, isPositive: true }}
          className="hover-scale"
          onClick={handleViewTransactions}
        />
        <StatCard
          title="Monthly Collection"
          value={stats.monthlyCollection}
          description="This month's collections"
          icon={<TrendingUp className="h-5 w-5 text-sangam-600" />}
          trend={{ value: 8, isPositive: true }}
          className="hover-scale"
          onClick={handleViewTransactions}
        />
        <StatCard
          title="Issued Loans"
          value={stats.issuedLoan}
          description="Total loan amount issued"
          icon={<CreditCard className="h-5 w-5 text-sangam-600" />}
          trend={{ value: 5, isPositive: true }}
          className="hover-scale"
          onClick={handleViewLoans}
        />
        <StatCard
          title="Pending Dues"
          value={stats.pendingDues}
          description="Outstanding payments"
          icon={<AlertTriangle className="h-5 w-5 text-red-500" />}
          trend={{ value: 10, isPositive: false }}
          className="hover-scale"
          onClick={() => toast.info("Viewing members with pending dues")}
        />
      </div>

      {/* Charts and Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <Card className="hover-scale">
          <CardHeader>
            <CardTitle>Monthly Funds Overview</CardTitle>
            <CardDescription>Chart showing fund growth over time</CardDescription>
          </CardHeader>
          <CardContent>
            <FundsChart />
          </CardContent>
        </Card>
        
        <Card className="hover-scale">
          <CardHeader>
            <CardTitle>Payment Status</CardTitle>
            <CardDescription>Monthly payment status breakdown</CardDescription>
          </CardHeader>
          <CardContent>
            <MonthlyPaymentChart />
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Activity */}
        <Card className="lg:col-span-2 hover-scale">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <div>
              <CardTitle>Recent Activity</CardTitle>
              <CardDescription>Latest actions and transactions</CardDescription>
            </div>
            <Button variant="outline" size="sm" onClick={handleViewTransactions}>
              <Clock className="mr-2 h-4 w-4" /> View All
            </Button>
          </CardHeader>
          <CardContent>
            <RecentActivity />
          </CardContent>
        </Card>

        {/* Notices */}
        <Card className="hover-scale">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <div>
              <CardTitle>Pending Dues</CardTitle>
              <CardDescription>Members with pending payments</CardDescription>
            </div>
            <div className="flex gap-2">
              <Button 
                size="sm" 
                variant="ghost"
                onClick={handleSendReminders}
                className="text-xs"
              >
                Send Reminders
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="border rounded-md p-3 bg-muted/20">
                <div className="flex justify-between mb-1">
                  <p className="font-medium">Rahul Sharma</p>
                  <p className="text-sm font-medium text-red-600">₹2,500</p>
                </div>
                <div className="flex justify-between text-sm text-muted-foreground">
                  <p>Due date: 05/05/2025</p>
                  <Button 
                    size="sm" 
                    variant="outline" 
                    className="h-7 text-xs"
                    onClick={handleMarkAllPaid}
                  >
                    Mark Paid
                  </Button>
                </div>
              </div>

              <div className="border rounded-md p-3 bg-muted/20">
                <div className="flex justify-between mb-1">
                  <p className="font-medium">Priya Patel</p>
                  <p className="text-sm font-medium text-red-600">₹1,500</p>
                </div>
                <div className="flex justify-between text-sm text-muted-foreground">
                  <p>Due date: 12/05/2025</p>
                  <Button 
                    size="sm" 
                    variant="outline" 
                    className="h-7 text-xs"
                    onClick={handleMarkAllPaid}
                  >
                    Mark Paid
                  </Button>
                </div>
              </div>

              <div className="border rounded-md p-3 bg-muted/20">
                <div className="flex justify-between mb-1">
                  <p className="font-medium">Vikram Kapoor</p>
                  <p className="text-sm font-medium text-red-600">₹3,000</p>
                </div>
                <div className="flex justify-between text-sm text-muted-foreground">
                  <p>Due date: 15/05/2025</p>
                  <Button 
                    size="sm" 
                    variant="outline" 
                    className="h-7 text-xs"
                    onClick={handleMarkAllPaid}
                  >
                    Mark Paid
                  </Button>
                </div>
              </div>
            </div>
            
            <div className="mt-4 pt-3 border-t">
              <Button 
                className="w-full text-sm bg-sangam-600 hover:bg-sangam-700"
                onClick={handleSendReminders}
              >
                Send Reminder to All
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="mt-6">
        <NoticeCard />
      </div>
    </div>
  );
};

export default Dashboard;
