
import { SidebarProvider } from '@/components/ui/sidebar';
import { AppSidebar } from '@/components/AppSidebar';
import Dashboard from './Dashboard';
import { Outlet } from 'react-router-dom';
import React from 'react';

const Index = () => {
  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full">
        <AppSidebar />
        <div className="flex-1 pl-16 md:pl-64">
          <Outlet />
        </div>
      </div>
    </SidebarProvider>
  );
};

export default Index;
