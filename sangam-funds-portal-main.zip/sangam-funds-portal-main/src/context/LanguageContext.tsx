import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

type Language = 'english' | 'telugu';

type Translations = {
  [key: string]: {
    english: string;
    telugu: string;
  };
};

// Define translations
const translations: Translations = {
  dashboard: {
    english: 'Dashboard',
    telugu: 'డాష్‌బోర్డ్',
  },
  members: {
    english: 'Members',
    telugu: 'సభ్యులు',
  },
  loans: {
    english: 'Loans',
    telugu: 'రుణాలు',
  },
  transactions: {
    english: 'Transactions',
    telugu: 'లావాదేవీలు',
  },
  reports: {
    english: 'Reports',
    telugu: 'నివేదికలు',
  },
  notices: {
    english: 'Notices',
    telugu: 'నోటీసులు',
  },
  watta: {
    english: 'Watta',
    telugu: 'వట్టా',
  },
  login: {
    english: 'Login',
    telugu: 'లాగిన్',
  },
  logout: {
    english: 'Logout',
    telugu: 'లాగ్అవుట్',
  },
  username: {
    english: 'Username',
    telugu: 'వినియోగదారు పేరు',
  },
  password: {
    english: 'Password',
    telugu: 'పాస్వర్డ్',
  },
  submit: {
    english: 'Submit',
    telugu: 'సమర్పించండి',
  },
  welcome: {
    english: 'Welcome to Sangam Portal',
    telugu: 'సంగం పోర్టల్‌కు స్వాగతం',
  },
  balance: {
    english: 'Balance',
    telugu: 'నిల్వ',
  },
  name: {
    english: 'Name',
    telugu: 'పేరు',
  },
  amount: {
    english: 'Amount',
    telugu: 'మొత్తం',
  },
  memberBalance: {
    english: 'Member Balance',
    telugu: 'సభ్యుని నిల్వ',
  },
  action: {
    english: 'Action',
    telugu: 'చర్య',
  },
  searchMember: {
    english: 'Search member...',
    telugu: 'సభ్యుని కోసం శోధించండి...',
  },
  view: {
    english: 'View',
    telugu: 'చూడండి',
  },
  selectLanguage: {
    english: 'Select Language',
    telugu: 'భాషను ఎంచుకోండి',
  },
  english: {
    english: 'English',
    telugu: 'ఇంగ్లీష్',
  },
  telugu: {
    english: 'Telugu',
    telugu: 'తెలుగు',
  },
  profile: {
    english: 'Profile',
    telugu: 'ప్రొఫైల్',
  }
};

interface LanguageContextType {
  language: Language;
  setLanguage: (language: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider = ({ children }: { children: ReactNode }) => {
  const [language, setLanguage] = useState<Language>(() => {
    // Try to get the language from localStorage
    const savedLanguage = localStorage.getItem('language');
    return (savedLanguage as Language) || 'english';
  });

  // Save language preference to localStorage
  useEffect(() => {
    localStorage.setItem('language', language);
  }, [language]);

  // Translation function
  const t = (key: string): string => {
    if (!translations[key]) {
      console.warn(`Translation key not found: ${key}`);
      return key;
    }
    return translations[key][language];
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
